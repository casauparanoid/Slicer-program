from __future__ import annotations

import argparse

from waam_slicer.config import load_config
from waam_slicer.klipper_client import KlipperClient


def main():
    parser = argparse.ArgumentParser(description="Test pTouch feedback through Klipper/Moonraker")
    parser.add_argument("--config", default="config.yaml")
    parser.add_argument(
        "--execute",
        action="store_true",
        help="Actually run LAYER_TOUCH. Without this flag, only print/check the command.",
    )
    args = parser.parse_args()

    cfg = load_config(args.config)
    adaptive = cfg["adaptive_control"]
    client = KlipperClient(
        adaptive["moonraker_url"],
        timeout=adaptive.get("request_timeout", 120),
    )

    macro = adaptive["touch_macro"]
    lift = float(adaptive["touch_lift"])
    probe_speed = float(adaptive["probe_speed"])
    command = f"{macro} LIFT={lift} SPEED={probe_speed}"

    client.require_ready()
    print(f"Klipper ready at {adaptive['moonraker_url']}")
    print(f"Touch command: {command}")

    if not args.execute:
        print("Dry run only. Add --execute to move the probe and read a new pTouch value.")
        return 0

    client.run_gcode(command)
    position = client.get_last_probe_position()
    p_touch = position["z"]

    H = float(cfg["slicing"]["layer_height_H"])
    correction = float(adaptive.get("z_correction_offset", 0.0))
    next_z = p_touch + H + correction

    print(f"pTouch X = {position['x']:.4f} mm")
    print(f"pTouch Y = {position['y']:.4f} mm")
    print(f"pTouch Z = {position['z']:.4f} mm")
    print(f"Next Z   = {next_z:.4f} mm (pTouch + H + correction)")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
