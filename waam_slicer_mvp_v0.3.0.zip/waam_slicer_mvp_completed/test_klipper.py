from __future__ import annotations

import argparse

from waam_slicer.config import load_config
from waam_slicer.klipper_client import KlipperClient


def main():
    parser = argparse.ArgumentParser(description="Test Moonraker/Klipper connection")
    parser.add_argument("--config", default="config.yaml")
    args = parser.parse_args()

    cfg = load_config(args.config)
    adaptive = cfg["adaptive_control"]
    client = KlipperClient(
        adaptive["moonraker_url"],
        timeout=adaptive.get("request_timeout", 120),
    )

    print(f"Connecting to {adaptive['moonraker_url']} ...")
    data = client.check_connection()
    state, message = client.get_printer_state()
    print("Moonraker connection: OK")
    print(f"Klipper state: {state}")
    if message:
        print(f"State message: {message}")
    if state != "ready":
        print("WARNING: network/API is reachable, but Klipper is not ready for motion.")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
