from __future__ import annotations

import argparse
import json
from pathlib import Path

from waam_slicer.config import load_config, resolve_path
from waam_slicer.gcode import export_layer_gcode
from waam_slicer.klipper_client import KlipperClient
from waam_slicer.mesh import load_mesh
from waam_slicer.placement import configure_placement
from waam_slicer.slicing import build_slices
from waam_slicer.toolpath import build_toolpath
from waam_slicer.validator import group_layers, validate_toolpath


def _load_checkpoint(path: Path) -> dict:
    if not path.exists():
        return {"completed_layer": -1, "next_layer": 0, "next_z_shift": 0.0, "history": []}
    return json.loads(path.read_text(encoding="utf-8"))


def _save_checkpoint(path: Path, state: dict) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(state, indent=2), encoding="utf-8")


def parse_args():
    p = argparse.ArgumentParser(description="Layer-by-layer adaptive WAAM controller")
    p.add_argument("--stl", required=True)
    p.add_argument("--config", default="config.yaml")
    p.add_argument("--execute", action="store_true", help="Actually send motion/probe commands")
    p.add_argument("--resume", action="store_true", help="Resume from checkpoint")
    p.add_argument("--reset-checkpoint", action="store_true")
    return p.parse_args()


def main():
    args = parse_args()
    cfg = load_config(args.config)
    adaptive = cfg["adaptive_control"]
    if not adaptive.get("enabled", False):
        raise RuntimeError("adaptive_control.enabled is false in config.yaml")

    mesh = load_mesh(args.stl, cfg)
    configure_placement(mesh, cfg)
    layers = build_slices(mesh, cfg)
    points = build_toolpath(layers, cfg)
    validate_toolpath(points, cfg)
    layer_map = group_layers(points)
    layer_ids = sorted(layer_map)
    if not layer_ids:
        raise RuntimeError("No layers available")

    checkpoint = resolve_path(cfg, adaptive["checkpoint_path"])
    if args.reset_checkpoint and checkpoint.exists():
        checkpoint.unlink()
    state = _load_checkpoint(checkpoint) if args.resume else {
        "completed_layer": -1, "next_layer": layer_ids[0], "next_z_shift": 0.0, "history": []
    }

    start_layer = int(state.get("next_layer", layer_ids[0]))
    if start_layer not in layer_map:
        print("Build already complete according to checkpoint.")
        return 0

    out_dir = resolve_path(cfg, adaptive["layer_gcode_dir"])
    out_dir.mkdir(parents=True, exist_ok=True)
    client = KlipperClient(adaptive["moonraker_url"], timeout=adaptive.get("request_timeout", 120))

    if args.execute:
        client.require_ready()
        print(f"Klipper ready: {adaptive['moonraker_url']}")
    else:
        print("DRY RUN: generate nominal per-layer G-code only; no machine movement/checkpoint update.")
        for layer_id in layer_ids:
            layer_file = out_dir / f"layer_{layer_id:04d}.gcode"
            export_layer_gcode(points, layer_id, cfg, layer_file, z_shift=0.0)
            print(f"Layer {layer_id}: nominal Z -> {layer_file}")
        print("Dry-run complete. No pTouch is simulated because no material was deposited.")
        return 0

    next_shift = float(state.get("next_z_shift", 0.0))
    H = float(cfg["slicing"]["layer_height_H"])
    correction = float(adaptive.get("z_correction_offset", 0.0))
    touch = adaptive["touch_macro"]
    lift = float(adaptive["touch_lift"])
    speed = float(adaptive["probe_speed"])

    start_pos = layer_ids.index(start_layer)
    for pos in range(start_pos, len(layer_ids)):
        layer_id = layer_ids[pos]
        layer_file = out_dir / f"layer_{layer_id:04d}.gcode"
        export_layer_gcode(points, layer_id, cfg, layer_file, z_shift=next_shift)
        print(f"Layer {layer_id}: z_shift={next_shift:+.4f} mm -> {layer_file}")

        client.run_gcode(layer_file.read_text(encoding="utf-8"))

        history_item = {"layer": layer_id, "z_shift": next_shift}
        state["completed_layer"] = layer_id

        if pos == len(layer_ids) - 1:
            state["next_layer"] = layer_id + 1
            state["next_z_shift"] = 0.0
            state["history"].append(history_item)
            _save_checkpoint(checkpoint, state)
            break

        command = f"{touch} LIFT={lift} SPEED={speed}"
        client.run_gcode(command)
        p = client.get_last_probe_position()
        p_touch = float(p["z"])
        next_id = layer_ids[pos + 1]
        nominal_next_z = float(layer_map[next_id][0].z)
        target_next_z = p_touch + H + correction
        next_shift = target_next_z - nominal_next_z
        history_item.update({"pTouch": p_touch, "target_next_z": target_next_z})
        print(
            f"  pTouch={p_touch:.4f} mm -> target Z(layer {next_id})={target_next_z:.4f} mm "
            f"-> shift={next_shift:+.4f} mm"
        )

        state["next_layer"] = layer_ids[pos + 1]
        state["next_z_shift"] = next_shift
        state["history"].append(history_item)
        _save_checkpoint(checkpoint, state)

    print(f"Checkpoint: {checkpoint}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
