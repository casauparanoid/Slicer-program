import math
import tempfile
import unittest
from pathlib import Path

from shapely.geometry import Polygon

from waam_slicer.gcode import export_gcode
from waam_slicer.slicing import SliceLayer
from waam_slicer.toolpath import build_toolpath
from waam_slicer.validator import group_paths, validate_toolpath


def base_config(tmpdir=None):
    root = str(tmpdir or Path.cwd())
    return {
        "_config_dir": root,
        "slicing": {"z_min": 1.5, "layer_height_H": 1.5},
        "toolpath": {
            "bead_width_W": 4.0,
            "offset_factor": 0.737,
            "contour_direction": "CW",
            "min_polygon_area": 0.2,
            "simplify_tolerance": 0.0,
            "waypoint_spacing": 0.5,
            "min_segment_length": 0.01,
            "collinear_tolerance": 1e-6,
            "buffer_quad_segs": 8,
            "max_offset_iterations": 100,
            "max_points_per_path": 100000,
        },
        "coordinate_system": {
            "cad_origin": [0.0, 0.0, 0.0],
            "machine_origin": [0.0, 0.0, 0.0],
        },
        "validation": {
            "enabled": True,
            "require_closed_paths": True,
            "coordinate_tolerance": 1e-6,
            "enforce_machine_limits": False,
            "machine_limits": {"x": [-100, 100], "y": [-100, 100], "z": [0, 100]},
        },
        "gcode": {
            "enabled": True,
            "output_path": "out.gcode",
            "deposition_feedrate": 400.0,
            "travel_feedrate": 2500.0,
            "safe_z_clearance": 5.0,
            "arc_start_command": "ARC_ON",
            "arc_stop_command": "ARC_OFF",
            "arc_start_dwell_ms": 0,
            "arc_stop_dwell_ms": 0,
            "sync_before_arc_off": True,
            "emit_arc_off_at_start": True,
            "program_end_command": "",
        },
        "wire_feed": {
            "enabled": False,
            "relative_extrusion": True,
            "wire_feed_speed_mm_s": 20.0,
            "e_precision": 5,
        },
    }


class WaypointTests(unittest.TestCase):
    def test_densification_limits_segment_length(self):
        cfg = base_config()
        layer = SliceLayer(0, 1.5, [Polygon([(0, 0), (10, 0), (10, 5), (0, 5)])])
        points = build_toolpath([layer], cfg)
        report = validate_toolpath(points, cfg)
        self.assertLessEqual(report.max_segment_mm, 0.500001)
        self.assertGreater(report.point_count, 30)

    def test_closed_paths(self):
        cfg = base_config()
        layer = SliceLayer(0, 1.5, [Polygon([(0, 0), (7, 0), (7, 3), (0, 3)])])
        points = build_toolpath([layer], cfg)
        for path in group_paths(points):
            self.assertAlmostEqual(path[0].x, path[-1].x)
            self.assertAlmostEqual(path[0].y, path[-1].y)
            self.assertEqual(path[0].status, "ARC_START")
            self.assertEqual(path[-1].status, "ARC_STOP")

    def test_wire_feed_uses_relative_positive_e(self):
        with tempfile.TemporaryDirectory() as td:
            cfg = base_config(td)
            cfg["wire_feed"]["enabled"] = True
            layer = SliceLayer(0, 1.5, [Polygon([(0, 0), (2, 0), (2, 2), (0, 2)])])
            points = build_toolpath([layer], cfg)
            output = export_gcode(points, cfg)
            text = output.read_text(encoding="utf-8")
            self.assertIn("M83", text)
            e_values = []
            for line in text.splitlines():
                if line.startswith("G1 ") and " E" in line:
                    for token in line.split():
                        if token.startswith("E"):
                            e_values.append(float(token[1:]))
            self.assertTrue(e_values)
            self.assertTrue(all(v > 0 for v in e_values))


if __name__ == "__main__":
    unittest.main()
