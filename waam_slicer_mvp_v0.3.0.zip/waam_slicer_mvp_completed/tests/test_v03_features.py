import math
import tempfile
import unittest
from pathlib import Path

import trimesh
from shapely.geometry import Polygon

from waam_slicer.curve import fit_circle, reconstruct_closed_ring
from waam_slicer.gcode import validate_gcode_motion
from waam_slicer.mesh import validate_mesh
from waam_slicer.placement import configure_placement
from waam_slicer.polygons import section_loops_to_polygons
from waam_slicer.slicing import SliceLayer, build_slices
from waam_slicer.toolpath import build_toolpath
from waam_slicer.validator import group_paths, validate_toolpath


def cfg_base():
    return {
        "slicing": {"z_min": 1.5, "layer_height_H": 1.5, "layer_count_mode": "ceil_partial", "surface_epsilon": 0.001},
        "mesh_validation": {
            "require_watertight": True,
            "require_winding_consistent": True,
            "require_single_body": False,
            "fail_on_degenerate_faces": True,
            "degenerate_area_tolerance": 1e-12,
            "require_closed_sections": True,
            "section_closure_tolerance": 0.02,
        },
        "toolpath": {
            "bead_width_W": 4.0,
            "offset_factor": 0.737,
            "contour_direction": "CW",
            "min_polygon_area": 0.2,
            "simplify_tolerance": 0.0,
            "waypoint_spacing": 0.5,
            "min_segment_length": 0.01,
            "collinear_tolerance": 1e-6,
            "buffer_quad_segs": 8,
            "max_offset_iterations": 100,
            "max_points_per_path": 100000,
        },
        "curve": {
            "enabled": True,
            "max_spacing": 0.5,
            "min_spacing": 0.1,
            "chord_tolerance": 0.05,
            "circle_fit_tolerance": 0.05,
            "corner_angle_deg": 20.0,
            "min_circle_points": 6,
        },
        "seam": {"strategy": "fixed", "base_angle_deg": 0, "angle_per_layer_deg": 137.507764, "angle_per_path_deg": 0},
        "path_order": {"strategy": "generated", "start_position_xy": None},
        "thin_wall": {"enabled": False, "width_threshold_factor": 0.5, "min_aspect_ratio": 2.0, "min_centerline_length": 2.0},
        "continuous_spiral": {"enabled": False, "circle_fit_tolerance": 0.05, "center_tolerance": 0.1},
        "coordinate_system": {"cad_origin": [0, 0, 0], "machine_origin": [0, 0, 0]},
        "placement": {"enabled": False, "mode": "manual", "margin_xy": 0, "build_area": {"x": [0, 300], "y": [0, 300]}},
        "validation": {
            "enabled": True,
            "require_closed_paths": True,
            "coordinate_tolerance": 1e-6,
            "enforce_machine_limits": False,
            "machine_limits": {"x": [0, 300], "y": [0, 300], "z": [0, 300]},
            "warn_segment_below_mm": 0.05,
        },
        "gcode": {
            "enabled": True, "output_path": "out.gcode", "deposition_feedrate": 400,
            "travel_feedrate": 2500, "safe_z_clearance": 5, "arc_start_command": "ARC_ON",
            "arc_stop_command": "ARC_OFF", "arc_start_dwell_ms": 0, "arc_stop_dwell_ms": 0,
            "sync_before_arc_off": True, "emit_arc_off_at_start": True, "program_end_command": "",
        },
        "wire_feed": {"enabled": False, "relative_extrusion": True, "wire_feed_speed_mm_s": 20, "e_precision": 5},
    }


class V03Features(unittest.TestCase):
    def test_circle_reconstruction(self):
        cfg = cfg_base()
        pts = []
        for i in range(24):
            a = 2 * math.pi * i / 24
            pts.append((10 * math.cos(a), 10 * math.sin(a)))
        pts.append(pts[0])
        rebuilt, meta = reconstruct_closed_ring(pts, cfg)
        self.assertEqual(meta["mode"], "circle")
        fit = fit_circle(rebuilt[:-1])
        self.assertIsNotNone(fit)
        self.assertLess(fit.max_residual, 1e-6)
        lengths = [math.hypot(b[0]-a[0], b[1]-a[1]) for a,b in zip(rebuilt, rebuilt[1:])]
        self.assertLessEqual(max(lengths), 0.500001)
        self.assertGreaterEqual(min(lengths), 0.09)

    def test_golden_seam_changes_layer_start(self):
        cfg = cfg_base()
        cfg["seam"]["strategy"] = "golden_angle"
        circle = Polygon([(10*math.cos(2*math.pi*i/64), 10*math.sin(2*math.pi*i/64)) for i in range(64)])
        pts = build_toolpath([SliceLayer(0, 1.5, [circle]), SliceLayer(1, 3.0, [circle])], cfg)
        paths = group_paths(pts)
        self.assertGreaterEqual(len(paths), 2)
        p0 = next(p for p in paths if p[0].layer_id == 0 and p[0].offset_index == 0)
        p1 = next(p for p in paths if p[0].layer_id == 1 and p[0].offset_index == 0)
        self.assertGreater(math.hypot(p0[0].x-p1[0].x, p0[0].y-p1[0].y), 1.0)

    def test_auto_placement_centers_model(self):
        cfg = cfg_base()
        cfg["placement"] = {"enabled": True, "mode": "center", "margin_xy": 10, "build_area": {"x": [0, 300], "y": [0, 300]}}
        mesh = trimesh.creation.box(extents=(50, 30, 20))
        dx, dy, _ = configure_placement(mesh, cfg)
        self.assertAlmostEqual(dx, 150.0)
        self.assertAlmostEqual(dy, 150.0)

    def test_partial_top_layer_count(self):
        cfg = cfg_base()
        mesh = trimesh.creation.cylinder(radius=15, height=10, sections=64)
        # Move bottom to Z=0.
        mesh.apply_translation((0, 0, 5))
        layers = build_slices(mesh, cfg)
        self.assertEqual(len(layers), 7)
        self.assertTrue(layers[-1].is_partial_top_layer)
        self.assertLess(layers[-1].z, 10.0)

    def test_open_section_is_not_silently_closed(self):
        cfg = cfg_base()
        loop = [(0,0,0), (10,0,0), (10,10,0), (0,10,0)]  # last endpoint is 10 mm from first
        with self.assertRaises(ValueError):
            section_loops_to_polygons([loop], min_area=0.2, closure_tolerance=0.02, require_closed=True)

    def test_safe_z_limit_is_checked(self):
        cfg = cfg_base()
        cfg["validation"]["enforce_machine_limits"] = True
        cfg["validation"]["machine_limits"] = {"x": [-10, 20], "y": [-10, 20], "z": [0, 5]}
        layer = SliceLayer(0, 1.5, [Polygon([(0,0),(2,0),(2,2),(0,2)])])
        points = build_toolpath([layer], cfg)
        # deposition Z=1.5 is legal; safe Z=6.5 is not.
        with self.assertRaises(ValueError):
            validate_gcode_motion(points, cfg)

    def test_mesh_validation_rejects_open_mesh(self):
        cfg = cfg_base()
        mesh = trimesh.creation.box(extents=(1,1,1))
        mesh.update_faces([True] * (len(mesh.faces)-1) + [False])
        mesh.remove_unreferenced_vertices()
        with self.assertRaises(ValueError):
            validate_mesh(mesh, cfg)

    def test_continuous_spiral_optional(self):
        cfg = cfg_base()
        cfg["continuous_spiral"]["enabled"] = True
        circle = Polygon([(15*math.cos(2*math.pi*i/96), 15*math.sin(2*math.pi*i/96)) for i in range(96)])
        points = build_toolpath([SliceLayer(0, 1.5, [circle])], cfg)
        paths = group_paths(points)
        self.assertEqual(len(paths), 1)
        self.assertEqual(paths[0][0].ring_type, "CONTINUOUS_SPIRAL")
        self.assertGreater(len(paths[0]), 100)
        validate_toolpath(points, cfg)


if __name__ == "__main__":
    unittest.main()
