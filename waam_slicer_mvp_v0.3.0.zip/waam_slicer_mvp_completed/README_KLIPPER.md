# Klipper / Moonraker integration

The offline slicer does not require a live printer. Klipper/Moonraker are used only for machine tests and adaptive layer execution.

## 1. Connection test

```powershell
python test_klipper.py --config config.yaml
```

A reachable Moonraker server is not sufficient. Klipper must report:

```text
state = ready
```

before motion commands are sent.

## 2. pTouch test

No-motion dry run:

```powershell
python test_ptouch.py
```

Actual touch cycle:

```powershell
python test_ptouch.py --execute
```

The script calls the configured `LAYER_TOUCH` macro and reads:

```text
probe.last_probe_position
```

Then:

```text
Z_next = pTouch + H + z_correction_offset
```

Validate `QUERY_PROBE`, Z direction, physical clearance and the macro manually in Mainsail before using `--execute`.

## 3. Adaptive layer controller

Enable in `config.yaml`:

```yaml
adaptive_control:
  enabled: true
```

Generate/check layer files without moving the machine:

```powershell
python run_adaptive.py --stl model\part.stl
```

Actual execution:

```powershell
python run_adaptive.py --stl model\part.stl --execute
```

Resume after a completed checkpoint:

```powershell
python run_adaptive.py --stl model\part.stl --execute --resume
```

The controller performs:

```text
PRINT LAYER k
    ↓
ARC_OFF / complete motion
    ↓
LAYER_TOUCH
    ↓
read pTouch_k
    ↓
Z_target(k+1) = pTouch_k + H + correction
    ↓
shift next layer G-code
    ↓
checkpoint
```

The controller sends one generated layer script at a time through Moonraker. For large production builds, a future version should use Moonraker file upload/print-job APIs rather than sending very large scripts through `/printer/gcode/script`.

## 4. Important limitation

`pTouch` is measured at the current probe XY location. It is a local height measurement, not a full layer-height map. Multi-point probing or vision/laser profiling is required if maximum/average layer geometry must be estimated.
