# Changelog

## 0.3.0

- Added strict mesh preflight: watertightness, winding, degenerate-face and body checks.
- Open slice contours are no longer silently closed beyond a configurable gap tolerance.
- Added `ceil_partial` layer-count mode and final partial top layer support.
- Added automatic XY placement inside a configured build area.
- Replaced pure edge densification with curve reconstruction/resampling:
  - circle fitting for supported circular contours;
  - sharp-corner preservation;
  - arclength resampling fallback for general polylines;
  - configurable chord and fit tolerances.
- Added seam rotation strategies including golden-angle distribution.
- Added nearest travel ordering inside each offset generation.
- Added optional concentric-circle continuous spiral mode (disabled by default).
- Added experimental thin-wall centerline mode (disabled by default).
- Added motion/curvature warning analysis without silently changing feedrate.
- Added G-code safe-Z and machine-envelope preflight.
- Refactored G-code renderer to support per-layer Z shifts.
- Added `run_adaptive.py` for layer-by-layer pTouch feedback with checkpoints/resume.
- Expanded test suite for curved geometry, placement, open contours, mesh safety, partial layers, safe-Z and optional spiral.

## 0.2.0

- Added controlled multi-waypoint G1 path generation.
- Added toolpath validation, CSV path metrics and optional relative-E wire feed.
- Added Moonraker readiness checks and pTouch dry-run protection.
