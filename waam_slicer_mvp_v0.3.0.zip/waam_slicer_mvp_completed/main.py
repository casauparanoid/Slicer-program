from __future__ import annotations

import argparse
from pathlib import Path

from waam_slicer.config import load_config
from waam_slicer.exporter import export_csv
from waam_slicer.gcode import export_gcode, validate_gcode_motion
from waam_slicer.kinematics import analyze_motion
from waam_slicer.mesh import inspect_mesh, load_mesh
from waam_slicer.placement import configure_placement
from waam_slicer.slicing import build_slices
from waam_slicer.toolpath import build_toolpath
from waam_slicer.validator import validate_toolpath
from waam_slicer.visualize import save_layer_previews


def select_stl_file() -> str:
    try:
        from tkinter import Tk, filedialog
    except ImportError as exc:
        raise RuntimeError("tkinter is unavailable; run with --stl path/to/model.stl") from exc
    root = Tk()
    root.withdraw()
    file_path = filedialog.askopenfilename(
        title="Select STL model",
        filetypes=[("STL files", "*.stl"), ("All files", "*.*")],
    )
    root.destroy()
    return file_path


def parse_args():
    parser = argparse.ArgumentParser(description="3-axis WAAM STL slicer")
    parser.add_argument("--stl", help="STL file. If omitted, a file picker opens.")
    parser.add_argument("--config", default="config.yaml", help="YAML configuration file")
    parser.add_argument("--no-preview", action="store_true", help="Do not save PNG layer previews")
    parser.add_argument("--no-gcode", action="store_true", help="Do not export G-code")
    return parser.parse_args()


def main():
    args = parse_args()
    cfg = load_config(args.config)

    stl_path = args.stl or select_stl_file()
    if not stl_path:
        print("No STL file selected.")
        return 1
    stl_path = str(Path(stl_path).expanduser().resolve())
    print(f"Selected model: {stl_path}")

    mesh = load_mesh(stl_path, cfg)
    report = inspect_mesh(mesh, cfg)
    size = mesh.extents
    print(f"Model size: X={size[0]:.2f} mm, Y={size[1]:.2f} mm, Z={size[2]:.2f} mm")
    print(
        "Mesh: "
        f"{report.vertices} vertices, {report.faces} faces, bodies={report.bodies}, "
        f"watertight={report.watertight}, winding={report.winding_consistent}, "
        f"degenerate={report.degenerate_faces}"
    )
    print("[1/8] Mesh validation OK")

    offset = configure_placement(mesh, cfg)
    print(f"[2/8] Placement offset: dX={offset[0]:.3f}, dY={offset[1]:.3f}, dZ={offset[2]:.3f} mm")

    layers = build_slices(mesh, cfg)
    if not layers:
        raise RuntimeError("No valid slices were generated")
    partial = sum(1 for layer in layers if layer.is_partial_top_layer)
    print(f"[3/8] Generated {len(layers)} valid slice(s); partial-top layers={partial}")

    points = build_toolpath(layers, cfg)
    if not points:
        raise RuntimeError("No toolpath points were generated")
    curve_modes = cfg.get("_runtime_metrics", {}).get("curve_modes", {})
    print(f"[4/8] Toolpath generated: {len(points)} points | curve modes={curve_modes}")

    if cfg.get("validation", {}).get("enabled", True):
        v = validate_toolpath(points, cfg)
        validate_gcode_motion(points, cfg)
        print(
            "[5/8] Geometry + machine preflight OK | "
            f"paths={v.path_count}, points={v.point_count}, "
            f"length={v.total_deposition_length_mm:.2f} mm, "
            f"segment={v.min_segment_mm:.4f}..{v.max_segment_mm:.4f} mm"
        )
        for warning in v.warnings:
            print(f"      WARNING: {warning}")
    else:
        print("[5/8] Validation disabled")

    if cfg.get("motion", {}).get("enabled", True):
        m = analyze_motion(points, cfg)
        radius = "n/a" if m.min_radius_mm is None else f"{m.min_radius_mm:.3f} mm"
        print(
            f"[6/8] Motion analysis | min radius={radius}, "
            f"max a_c={m.max_centripetal_accel_mm_s2:.2f} mm/s^2, sharp turns={m.sharp_turn_count}"
        )
        for warning in m.warnings:
            print(f"      WARNING: {warning}")
    else:
        print("[6/8] Motion analysis disabled")

    csv_path = export_csv(points, cfg)
    print(f"[7/8] CSV: {csv_path}")

    if cfg["export"].get("save_layer_images", True) and not args.no_preview:
        image_dir = save_layer_previews(layers, points, cfg)
        print(f"      Layer images: {image_dir}")

    if cfg["gcode"].get("enabled", True) and not args.no_gcode:
        gcode_path = export_gcode(points, cfg)
        print(f"[8/8] G-code: {gcode_path}")
    else:
        print("[8/8] G-code export disabled")

    print("Done. Dry-run the generated file with ARC/WIRE disabled before deposition tests.")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
