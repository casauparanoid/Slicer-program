# Upgrade notes: 0.2.0 → 0.3.0

The default behavior intentionally changed in several places. Review these before using old machine programs.

1. **Machine limits are enabled by default.** Replace the example 0–300 mm limits with the real machine travel.
2. **Automatic XY placement is enabled.** Set `placement.enabled: false` if you want the old CAD-origin behavior.
3. **Layer counting defaults to `ceil_partial`.** A part whose height is not an exact multiple of `H` receives a final partial top layer. Use `legacy` to reproduce the old count.
4. **Curved circles may be reconstructed from STL section points.** Output remains multi-waypoint `G1`, but points can lie on the fitted circle rather than on the original tessellated chords.
5. **Seams use golden-angle rotation by default.** Set `seam.strategy: fixed` for old behavior.
6. **Path ordering is optimized inside each offset generation.** Set `path_order.strategy: generated` to preserve generation order.
7. **Continuous spiral and thin-wall centerline are experimental and remain disabled.**
8. **Adaptive execution is a separate controller (`run_adaptive.py`) and remains disabled until explicitly enabled.**

Always perform a dry run with arc and wire disabled after upgrading.
