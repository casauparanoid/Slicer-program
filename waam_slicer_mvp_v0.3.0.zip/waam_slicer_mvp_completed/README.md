# WAAM Slicer 0.3.0 — Python / Trimesh / Shapely / Klipper

Custom slicer for a 3-axis WAAM machine. The project converts STL geometry into contour-parallel deposition paths, validates the geometry and machine envelope, then exports CSV, preview images and Klipper-oriented G-code.

Version **0.3.0** upgrades the earlier multi-waypoint prototype into a safer research baseline for curved WAAM paths and later adaptive-Z execution.

```text
STL
 ↓
Mesh validation
 ↓
Automatic XY placement
 ↓
Horizontal slicing
 ↓
Closed-section validation
 ↓
Shapely polygons / holes
 ↓
Contour + inward offset d = 0.737W
 ↓
Curve reconstruction
 ├─ circular run → fitted circle
 └─ other shape  → source polyline
 ↓
Adaptive/uniform waypoint resampling
 ↓
Seam rotation + path ordering
 ↓
Toolpath + motion validation
 ↓
CSV / preview / G-code
 ↓
Klipper
```

## 1. Installation

Recommended Python 3.11–3.13.

```powershell
cd E:\waam_slicer_mvp
python -m venv .venv
Set-ExecutionPolicy -Scope Process -ExecutionPolicy Bypass
.\.venv\Scripts\Activate.ps1
python -m pip install -r requirements.txt
```

Do not copy `.venv` between computers. Recreate it from `requirements.txt`.

## 2. Run

Graphical STL picker:

```powershell
python main.py
```

Direct file:

```powershell
python main.py --stl "model\curved_cylinder_R15_H10.stl" --config config.yaml
```

Outputs:

```text
output/toolpath.csv
output/toolpath.gcode
output/layers/layer_XXXX.png
```

## 3. Main changes in v0.3

### Mesh preflight

Before slicing, the program can require:

- watertight STL;
- consistent face winding;
- no degenerate faces;
- optionally one connected body;
- closed slice sections.

An open section is no longer silently closed unless its endpoint gap is below `section_closure_tolerance`.

```yaml
mesh_validation:
  require_watertight: true
  require_winding_consistent: true
  require_closed_sections: true
  section_closure_tolerance: 0.02
```

### Layer count and final partial layer

The old version stopped at the last full slicing height. With `ceil_partial`, the slicer adds a final partial top layer if the CAD height is not an exact multiple of `H`.

```yaml
slicing:
  z_min: 1.5
  layer_height_H: 1.5
  layer_count_mode: ceil_partial
  surface_epsilon: 0.001
```

Example: a 10 mm-high cylinder with `H = 1.5 mm` produces 7 layers instead of 6. The last slice is placed slightly below the exact top surface to avoid a degenerate plane/mesh intersection.

### Automatic XY placement

The slicer can place the model inside the configured build area before toolpath export.

```yaml
placement:
  enabled: true
  mode: center
  margin_xy: 10.0
  build_area:
    x: [0.0, 300.0]
    y: [0.0, 300.0]
```

A cylinder centered at CAD `(0,0)` therefore no longer needs to generate negative machine X/Y values.

## 4. Curved paths: multi-waypoint G1

The production strategy remains intentionally simple:

```text
curve → P0, P1, P2, ... Pn → G1, G1, G1, ... G1
```

However, v0.3 no longer performs only blind densification of STL edges.

### Circular reconstruction

When a smooth set of section vertices fits a circle within the configured radial tolerance, the slicer reconstructs that circle and resamples it. This is especially useful for cylinders and circular holes represented by tessellated STL triangles.

```yaml
curve:
  enabled: true
  max_spacing: 0.5
  min_spacing: 0.10
  chord_tolerance: 0.05
  circle_fit_tolerance: 0.05
  corner_angle_deg: 20.0
  min_circle_points: 6
```

The output still uses only `G1`; no `G2/G3` is required.

### Other geometry

Sharp corners are detected and preserved. Non-circular sections fall back to the original polyline geometry, but are resampled by arclength so waypoint spacing is much more uniform than in v0.2.

Important limitation: the slicer cannot recover an arbitrary exact CAD/NURBS curve that was destroyed during STL tessellation. Circular fitting is only accepted when the observed points support it within tolerance. A sufficiently fine STL remains important.

## 5. Seam control

Repeated `ARC_ON/ARC_OFF` at the same XY can build a vertical seam and concentrate heat. Version 0.3 can rotate the start point between layers.

```yaml
seam:
  strategy: golden_angle
  angle_per_layer_deg: 137.507764
```

Available strategies:

```text
fixed
rotate
golden_angle
```

For circular parts, `golden_angle` distributes starts around the circumference instead of stacking them at one location.

## 6. Path ordering

Within each inward-offset generation, independent paths are ordered by nearest start point to reduce non-deposition travel while preserving the outside-to-inside offset sequence.

```yaml
path_order:
  strategy: offset_then_nearest
```

This is intentionally not a thermal optimizer yet. It only reduces unnecessary travel.

## 7. Optional continuous spiral

For a layer that consists of one family of concentric circular exterior paths, the slicer can replace separate closed contours with a single continuous spiral.

```yaml
continuous_spiral:
  enabled: false
```

It is **disabled by default** because continuous deposition changes heat accumulation, bead behavior, start/stop logic **and total path length/material demand** relative to discrete contours. Enable only for controlled experiments and re-check WFS/deposition volume.

## 8. Thin-wall mode

An experimental centerline mode is included for simple elongated regions too narrow for a normal inward offset.

```yaml
thin_wall:
  enabled: false
```

The implementation uses the major axis of the minimum rotated rectangle and clips it to the polygon. It is not a general medial-axis/skeleton algorithm, so it must remain off until validated for the target part geometry.

## 9. Machine and G-code validation

Toolpath validation checks:

- finite XYZ coordinates;
- point IDs and path status sequence;
- closure for normal contours;
- zero-length segments;
- maximum waypoint spacing;
- machine X/Y/Z limits.

The G-code preflight also checks travel moves, especially:

```text
safe_z = deposition_z + safe_z_clearance
```

so a legal deposition Z cannot accidentally produce an out-of-range `G0 Z...` move.

```yaml
validation:
  enforce_machine_limits: true
  machine_limits:
    x: [0.0, 300.0]
    y: [0.0, 300.0]
    z: [0.0, 300.0]
```

Replace these example limits with the actual machine limits before printing.

## 10. Motion analysis

The program estimates local turn severity and three-point curvature from the generated waypoint path. At the nominal deposition speed it estimates centripetal acceleration:

```text
a_c = v² / R
```

Warnings are produced for sharp turns. Set `max_centripetal_accel_mm_s2` to the measured/configured machine value if you also want an acceleration-limit warning; `0.0` disables that threshold.

```yaml
motion:
  max_centripetal_accel_mm_s2: 0.0
  sharp_turn_warning_deg: 45.0
```

This is a **preflight warning**, not automatic process control. Automatically slowing a WAAM path would change deposition per unit length unless wire feed/current are coordinated, so v0.3 does not silently change feedrate.

## 11. Wire feed

Optional relative-E synchronization remains available but disabled by default.

```yaml
wire_feed:
  enabled: false
  relative_extrusion: true
  wire_feed_speed_mm_s: 20.0
```

When enabled, the postprocessor uses `M83` and positive relative E increments. Enable only after the feeder is calibrated so the E axis has a known physical meaning.

## 12. Adaptive Z / pTouch

Offline `main.py` still generates a nominal complete build. A separate controller is included for layer-by-layer adaptive experiments:

```powershell
python run_adaptive.py --stl model\part.stl
```

Dry-run is the default. Actual machine execution requires:

```powershell
python run_adaptive.py --stl model\part.stl --execute
```

and:

```yaml
adaptive_control:
  enabled: true
```

After layer `k`, the controller runs `LAYER_TOUCH`, reads `probe.last_probe_position`, and computes:

```text
Z_target(k+1) = pTouch(k) + H + z_correction_offset
```

It then applies a Z shift to the next nominal layer and writes a checkpoint JSON after every layer. `--resume` can continue from that checkpoint.

This is still **single-point height feedback**. It does not measure the maximum/average layer height over the whole deposited surface.

## 13. Current architecture

```text
waam_slicer/
├── config.py
├── mesh.py
├── slicing.py
├── polygons.py
├── curve.py          # circle fitting + resampling
├── thinwall.py       # experimental
├── placement.py      # machine XY placement
├── toolpath.py
├── validator.py
├── kinematics.py     # motion warnings
├── exporter.py
├── gcode.py
├── visualize.py
└── klipper_client.py

main.py               # offline slicer
run_adaptive.py       # layer-by-layer adaptive controller
test_klipper.py
test_ptouch.py
```

## 14. Tests

Run:

```powershell
python -m unittest discover -s tests -v
```

The suite includes tests for:

- waypoint spacing;
- circular reconstruction;
- seam rotation;
- partial top layer count;
- open contour rejection;
- mesh validation;
- automatic placement;
- safe-Z machine-limit preflight;
- positive relative-E wire feed;
- optional concentric spiral.

## 15. Recommended commissioning order

```text
1. Validate STL / slice previews
2. Dry-run XYZ with ARC_OFF and wire disabled
3. Confirm real machine limits and placement
4. Test feeder independently
5. Test ARC_ON / ARC_OFF independently
6. Print one straight path
7. Print one circular multi-waypoint path
8. Compare 1.0 / 0.5 / 0.25 mm waypoint spacing
9. Validate seam rotation / heat behavior
10. Only then test adaptive pTouch layer-by-layer
```

`G2/G3`, general NURBS reconstruction and AI-predicted `H/W` remain later research stages. Version 0.3 intentionally prioritizes a testable, inspectable `G1` waypoint baseline.
