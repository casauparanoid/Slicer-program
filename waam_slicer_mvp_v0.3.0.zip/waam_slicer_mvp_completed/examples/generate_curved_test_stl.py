from pathlib import Path

import trimesh


ROOT = Path(__file__).resolve().parents[1]
OUT = ROOT / "model" / "curved_cylinder_R15_H10.stl"

mesh = trimesh.creation.cylinder(radius=15.0, height=10.0, sections=128)
# trimesh cylinder is centered around Z=0; move its bottom to Z=0.
mesh.apply_translation([0.0, 0.0, 5.0])
OUT.parent.mkdir(parents=True, exist_ok=True)
mesh.export(OUT)
print(f"Created: {OUT}")
