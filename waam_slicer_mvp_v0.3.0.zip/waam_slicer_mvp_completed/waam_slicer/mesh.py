from __future__ import annotations

from dataclasses import dataclass, field
from pathlib import Path

import numpy as np
import trimesh


@dataclass
class MeshReport:
    vertices: int
    faces: int
    bodies: int
    watertight: bool
    winding_consistent: bool
    is_volume: bool
    euler_number: int | None
    degenerate_faces: int
    warnings: list[str] = field(default_factory=list)


def inspect_mesh(mesh: trimesh.Trimesh, cfg: dict | None = None) -> MeshReport:
    cfg = cfg or {}
    areas = np.asarray(mesh.area_faces, dtype=float) if len(mesh.faces) else np.asarray([])
    area_tol = float(cfg.get("mesh_validation", {}).get("degenerate_area_tolerance", 1e-12))
    degenerate = int(np.count_nonzero(areas <= area_tol)) if len(areas) else 0
    try:
        bodies = len(mesh.split(only_watertight=False))
    except Exception:
        bodies = int(getattr(mesh, "body_count", 1) or 1)
    warnings = []
    if not mesh.is_watertight:
        warnings.append("Mesh is not watertight.")
    if not mesh.is_winding_consistent:
        warnings.append("Mesh face winding is inconsistent.")
    if bodies != 1:
        warnings.append(f"Mesh contains {bodies} disconnected bodies.")
    if degenerate:
        warnings.append(f"Mesh contains {degenerate} degenerate/near-zero-area faces.")
    return MeshReport(
        vertices=len(mesh.vertices),
        faces=len(mesh.faces),
        bodies=bodies,
        watertight=bool(mesh.is_watertight),
        winding_consistent=bool(mesh.is_winding_consistent),
        is_volume=bool(mesh.is_volume),
        euler_number=int(mesh.euler_number) if mesh.euler_number is not None else None,
        degenerate_faces=degenerate,
        warnings=warnings,
    )


def validate_mesh(mesh: trimesh.Trimesh, cfg: dict) -> MeshReport:
    report = inspect_mesh(mesh, cfg)
    m = cfg.get("mesh_validation", {})
    if m.get("require_watertight", True) and not report.watertight:
        raise ValueError("Mesh validation failed: STL is not watertight")
    if m.get("require_winding_consistent", True) and not report.winding_consistent:
        raise ValueError("Mesh validation failed: face winding is inconsistent")
    if m.get("require_single_body", False) and report.bodies != 1:
        raise ValueError(f"Mesh validation failed: expected one body, found {report.bodies}")
    if m.get("fail_on_degenerate_faces", True) and report.degenerate_faces:
        raise ValueError(
            f"Mesh validation failed: {report.degenerate_faces} degenerate/near-zero-area faces"
        )
    return report


def load_mesh(path: str | Path, cfg: dict | None = None) -> trimesh.Trimesh:
    path = Path(path).expanduser().resolve()
    if not path.exists():
        raise FileNotFoundError(f"Mesh not found: {path}")

    loaded = trimesh.load(path, force="mesh")
    if isinstance(loaded, trimesh.Scene):
        if not loaded.geometry:
            raise ValueError("Scene contains no geometry")
        mesh = trimesh.util.concatenate(tuple(loaded.geometry.values()))
    else:
        mesh = loaded

    if mesh is None or mesh.is_empty:
        raise ValueError("Mesh is empty")
    if not isinstance(mesh, trimesh.Trimesh):
        raise TypeError(f"Expected Trimesh, got {type(mesh).__name__}")

    mesh.remove_unreferenced_vertices()
    if len(mesh.vertices) < 3 or len(mesh.faces) < 1:
        raise ValueError("Mesh does not contain enough vertices/faces")
    if not np.isfinite(mesh.vertices).all():
        raise ValueError("Mesh contains non-finite vertex coordinates")

    if cfg is not None:
        validate_mesh(mesh, cfg)
    return mesh
