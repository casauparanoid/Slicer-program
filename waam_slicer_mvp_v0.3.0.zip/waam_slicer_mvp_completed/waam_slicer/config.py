from __future__ import annotations

from copy import deepcopy
from pathlib import Path
from typing import Any

import yaml


DEFAULT_CONFIG: dict[str, Any] = {
    "slicing": {
        "z_min": 1.5,
        "layer_height_H": 1.5,
        "layer_count_mode": "ceil_partial",
        "surface_epsilon": 0.001,
    },
    "mesh_validation": {
        "require_watertight": True,
        "require_winding_consistent": True,
        "require_single_body": False,
        "fail_on_degenerate_faces": True,
        "degenerate_area_tolerance": 1e-12,
        "require_closed_sections": True,
        "section_closure_tolerance": 0.02,
    },
    "toolpath": {
        "bead_width_W": 4.0,
        "offset_factor": 0.737,
        "contour_direction": "CW",
        "min_polygon_area": 0.2,
        "simplify_tolerance": 0.0,
        # Kept for backwards compatibility; curve.max_spacing is authoritative.
        "waypoint_spacing": 0.5,
        "min_segment_length": 0.01,
        "collinear_tolerance": 1e-6,
        "buffer_quad_segs": 8,
        "max_offset_iterations": 10000,
        "max_points_per_path": 200000,
    },
    "curve": {
        "enabled": True,
        "mode": "auto",
        "max_spacing": 0.5,
        "min_spacing": 0.10,
        "chord_tolerance": 0.05,
        "circle_fit_tolerance": 0.05,
        "corner_angle_deg": 20.0,
        "min_circle_points": 6,
    },
    "seam": {
        "strategy": "golden_angle",
        "base_angle_deg": 0.0,
        "angle_per_layer_deg": 137.507764,
        "angle_per_path_deg": 0.0,
    },
    "path_order": {
        "strategy": "offset_then_nearest",
        "start_position_xy": None,
    },
    "continuous_spiral": {
        "enabled": False,
        "circle_fit_tolerance": 0.05,
        "center_tolerance": 0.10,
    },
    "thin_wall": {
        "enabled": False,
        "width_threshold_factor": 0.5,
        "min_aspect_ratio": 2.0,
        "min_centerline_length": 2.0,
    },
    "coordinate_system": {
        "cad_origin": [0.0, 0.0, 0.0],
        "machine_origin": [0.0, 0.0, 0.0],
    },
    "placement": {
        "enabled": True,
        "mode": "center",
        "margin_xy": 10.0,
        "build_area": {
            "x": [0.0, 300.0],
            "y": [0.0, 300.0],
        },
    },
    "export": {
        "csv_path": "output/toolpath.csv",
        "save_layer_images": True,
        "image_dir": "output/layers",
        "show_waypoints": True,
        "waypoint_marker_every": 10,
    },
    "validation": {
        "enabled": True,
        "require_closed_paths": True,
        "coordinate_tolerance": 1e-6,
        "enforce_machine_limits": True,
        "machine_limits": {
            "x": [0.0, 300.0],
            "y": [0.0, 300.0],
            "z": [0.0, 300.0],
        },
        "warn_segment_below_mm": 0.05,
    },
    "motion": {
        "enabled": True,
        "max_centripetal_accel_mm_s2": 0.0,
        "sharp_turn_warning_deg": 45.0,
    },
    "gcode": {
        "enabled": True,
        "output_path": "output/toolpath.gcode",
        "deposition_feedrate": 400.0,
        "travel_feedrate": 2500.0,
        "safe_z_clearance": 5.0,
        "arc_start_command": "ARC_ON",
        "arc_stop_command": "ARC_OFF",
        "arc_start_dwell_ms": 500,
        "arc_stop_dwell_ms": 300,
        "sync_before_arc_off": True,
        "emit_arc_off_at_start": True,
        "program_end_command": "",
    },
    "wire_feed": {
        "enabled": False,
        "relative_extrusion": True,
        "wire_feed_speed_mm_s": 20.0,
        "e_precision": 5,
    },
    "adaptive_control": {
        "enabled": False,
        "moonraker_url": "http://192.168.0.2:7125",
        "touch_macro": "LAYER_TOUCH",
        "touch_lift": 0.1,
        "probe_speed": 0.5,
        "request_timeout": 120,
        "z_correction_offset": 0.0,
        "checkpoint_path": "output/build_state.json",
        "layer_gcode_dir": "output/adaptive_layers",
    },
}


def _deep_update(base: dict, override: dict) -> dict:
    for key, value in override.items():
        if isinstance(value, dict) and isinstance(base.get(key), dict):
            _deep_update(base[key], value)
        else:
            base[key] = value
    return base


def _positive(value: Any, name: str) -> float:
    number = float(value)
    if number <= 0:
        raise ValueError(f"{name} must be > 0")
    return number


def _non_negative(value: Any, name: str) -> float:
    number = float(value)
    if number < 0:
        raise ValueError(f"{name} must be >= 0")
    return number


def _validate_origin(value: Any, name: str) -> None:
    if not isinstance(value, (list, tuple)) or len(value) != 3:
        raise ValueError(f"{name} must contain exactly [X, Y, Z]")
    [float(v) for v in value]


def _validate_limits(value: Any, name: str) -> None:
    if not isinstance(value, (list, tuple)) or len(value) != 2:
        raise ValueError(f"{name} must be [min, max]")
    lo, hi = map(float, value)
    if lo >= hi:
        raise ValueError(f"{name}: min must be < max")


def validate_config(cfg: dict) -> dict:
    direction = str(cfg["toolpath"].get("contour_direction", "CW")).upper()
    if direction not in {"CW", "CCW", "ALTERNATE"}:
        raise ValueError("contour_direction must be CW, CCW, or ALTERNATE")
    cfg["toolpath"]["contour_direction"] = direction

    _positive(cfg["slicing"]["layer_height_H"], "layer_height_H")
    _non_negative(cfg["slicing"]["z_min"], "z_min")
    _non_negative(cfg["slicing"].get("surface_epsilon", 0.001), "surface_epsilon")
    if str(cfg["slicing"].get("layer_count_mode", "ceil_partial")).lower() not in {
        "legacy", "floor", "ceil_partial"
    }:
        raise ValueError("layer_count_mode must be legacy/floor or ceil_partial")

    _positive(cfg["toolpath"]["bead_width_W"], "bead_width_W")
    _positive(cfg["toolpath"]["offset_factor"], "offset_factor")
    _non_negative(cfg["toolpath"]["min_polygon_area"], "min_polygon_area")
    _non_negative(cfg["toolpath"]["simplify_tolerance"], "simplify_tolerance")
    _non_negative(cfg["toolpath"]["waypoint_spacing"], "waypoint_spacing")
    _non_negative(cfg["toolpath"]["min_segment_length"], "min_segment_length")
    _non_negative(cfg["toolpath"]["collinear_tolerance"], "collinear_tolerance")
    if int(cfg["toolpath"]["buffer_quad_segs"]) < 1:
        raise ValueError("buffer_quad_segs must be >= 1")
    if int(cfg["toolpath"]["max_offset_iterations"]) < 1:
        raise ValueError("max_offset_iterations must be >= 1")
    if int(cfg["toolpath"]["max_points_per_path"]) < 4:
        raise ValueError("max_points_per_path must be >= 4")

    curve = cfg.get("curve", {})
    _positive(curve.get("max_spacing", 0.5), "curve.max_spacing")
    _non_negative(curve.get("min_spacing", 0.0), "curve.min_spacing")
    _non_negative(curve.get("chord_tolerance", 0.05), "curve.chord_tolerance")
    _non_negative(curve.get("circle_fit_tolerance", 0.05), "curve.circle_fit_tolerance")
    if float(curve.get("min_spacing", 0.0)) > float(curve.get("max_spacing", 0.5)):
        raise ValueError("curve.min_spacing must be <= curve.max_spacing")
    if int(curve.get("min_circle_points", 6)) < 3:
        raise ValueError("curve.min_circle_points must be >= 3")

    _validate_origin(cfg["coordinate_system"]["cad_origin"], "cad_origin")
    _validate_origin(cfg["coordinate_system"]["machine_origin"], "machine_origin")

    placement = cfg.get("placement", {})
    if placement.get("enabled", False):
        mode = str(placement.get("mode", "center")).lower()
        if mode not in {"manual", "center", "min_corner", "lower_left"}:
            raise ValueError("placement.mode must be manual, center, or min_corner")
        _non_negative(placement.get("margin_xy", 0.0), "placement.margin_xy")
        _validate_limits(placement.get("build_area", {}).get("x"), "placement.build_area.x")
        _validate_limits(placement.get("build_area", {}).get("y"), "placement.build_area.y")

    seam = cfg.get("seam", {})
    if str(seam.get("strategy", "fixed")).lower() not in {"fixed", "original", "none", "rotate", "golden_angle"}:
        raise ValueError("seam.strategy must be fixed, rotate, or golden_angle")

    if str(cfg.get("path_order", {}).get("strategy", "offset_then_nearest")).lower() not in {
        "generated", "none", "offset_then_nearest"
    }:
        raise ValueError("path_order.strategy must be generated or offset_then_nearest")

    spiral = cfg.get("continuous_spiral", {})
    _non_negative(spiral.get("circle_fit_tolerance", 0.05), "continuous_spiral.circle_fit_tolerance")
    _non_negative(spiral.get("center_tolerance", 0.10), "continuous_spiral.center_tolerance")

    thin = cfg.get("thin_wall", {})
    _positive(thin.get("min_aspect_ratio", 2.0), "thin_wall.min_aspect_ratio")
    _non_negative(thin.get("min_centerline_length", 2.0), "thin_wall.min_centerline_length")

    mv = cfg.get("mesh_validation", {})
    _non_negative(mv.get("section_closure_tolerance", 0.02), "section_closure_tolerance")
    _non_negative(mv.get("degenerate_area_tolerance", 1e-12), "degenerate_area_tolerance")

    _positive(cfg["gcode"]["deposition_feedrate"], "deposition_feedrate")
    _positive(cfg["gcode"]["travel_feedrate"], "travel_feedrate")
    _non_negative(cfg["gcode"]["safe_z_clearance"], "safe_z_clearance")

    if cfg["wire_feed"].get("enabled", False):
        _positive(cfg["wire_feed"]["wire_feed_speed_mm_s"], "wire_feed_speed_mm_s")
        if not cfg["wire_feed"].get("relative_extrusion", True):
            raise ValueError("This postprocessor requires relative E mode (M83)")

    if cfg["validation"].get("enforce_machine_limits", False):
        limits = cfg["validation"]["machine_limits"]
        for axis in ("x", "y", "z"):
            _validate_limits(limits.get(axis), f"machine_limits.{axis}")

    return cfg


def load_config(path: str | Path) -> dict:
    path = Path(path).expanduser().resolve()
    if not path.exists():
        raise FileNotFoundError(f"Configuration file not found: {path}")
    with path.open("r", encoding="utf-8") as f:
        loaded = yaml.safe_load(f) or {}
    if not isinstance(loaded, dict):
        raise ValueError("Top-level YAML configuration must be a mapping")
    cfg = _deep_update(deepcopy(DEFAULT_CONFIG), loaded)
    # Backwards compatibility: old waypoint_spacing becomes max curve spacing if
    # the new curve section was not explicitly provided.
    if "curve" not in loaded and "toolpath" in loaded and "waypoint_spacing" in loaded["toolpath"]:
        cfg["curve"]["max_spacing"] = float(loaded["toolpath"]["waypoint_spacing"])
    cfg["_config_dir"] = str(path.parent)
    cfg["_config_path"] = str(path)
    return validate_config(cfg)


def resolve_path(cfg: dict, value: str | Path) -> Path:
    path = Path(value).expanduser()
    if path.is_absolute():
        return path
    return Path(cfg.get("_config_dir", ".")) / path
