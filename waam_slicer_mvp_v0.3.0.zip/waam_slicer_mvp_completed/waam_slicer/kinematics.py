from __future__ import annotations

import math
from dataclasses import dataclass, field

from .validator import group_paths


@dataclass
class MotionReport:
    min_radius_mm: float | None
    max_centripetal_accel_mm_s2: float
    sharp_turn_count: int
    warnings: list[str] = field(default_factory=list)


def _circumradius(a, b, c):
    ab = math.hypot(b.x - a.x, b.y - a.y)
    bc = math.hypot(c.x - b.x, c.y - b.y)
    ca = math.hypot(a.x - c.x, a.y - c.y)
    area2 = abs((b.x - a.x) * (c.y - a.y) - (b.y - a.y) * (c.x - a.x))
    if area2 <= 1e-12:
        return None
    # R = abc / 4A; area2 = 2A.
    return (ab * bc * ca) / (2.0 * area2)


def analyze_motion(points, cfg: dict) -> MotionReport:
    m = cfg.get("motion", {})
    feed = float(cfg["gcode"]["deposition_feedrate"]) / 60.0
    accel_limit = float(m.get("max_centripetal_accel_mm_s2", 0.0))
    sharp_angle = float(m.get("sharp_turn_warning_deg", 45.0))
    min_radius = None
    max_accel = 0.0
    sharp = 0
    warnings = []

    for path in group_paths(points):
        for a, b, c in zip(path, path[1:], path[2:]):
            v1 = (b.x - a.x, b.y - a.y)
            v2 = (c.x - b.x, c.y - b.y)
            n1 = math.hypot(*v1)
            n2 = math.hypot(*v2)
            if n1 <= 1e-12 or n2 <= 1e-12:
                continue
            dot = max(-1.0, min(1.0, (v1[0] * v2[0] + v1[1] * v2[1]) / (n1 * n2)))
            turn = math.degrees(math.acos(dot))
            if turn >= sharp_angle:
                sharp += 1
            r = _circumradius(a, b, c)
            if r is not None and r > 1e-9:
                min_radius = r if min_radius is None else min(min_radius, r)
                acc = feed * feed / r
                max_accel = max(max_accel, acc)

    if accel_limit > 0 and max_accel > accel_limit:
        warnings.append(
            f"Estimated centripetal acceleration {max_accel:.2f} mm/s^2 exceeds configured "
            f"limit {accel_limit:.2f} mm/s^2. Review feedrate/curvature before printing."
        )
    if sharp:
        warnings.append(
            f"Detected {sharp} toolpath turns >= {sharp_angle:.1f}°. These may cause local speed changes "
            "and WAAM over-deposition; verify Klipper motion and process parameters."
        )
    return MotionReport(min_radius, max_accel, sharp, warnings)
