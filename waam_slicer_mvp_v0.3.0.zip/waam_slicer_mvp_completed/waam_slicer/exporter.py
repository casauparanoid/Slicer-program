from __future__ import annotations

import csv
import math
from collections import defaultdict

from .config import resolve_path


FIELDS = [
    "layer_id",
    "polygon_id",
    "offset_index",
    "ring_type",
    "point_id",
    "x",
    "y",
    "z",
    "status",
    "segment_length",
    "cumulative_length",
    "path_length",
]


def _distance(a, b) -> float:
    return math.sqrt((b.x - a.x) ** 2 + (b.y - a.y) ** 2 + (b.z - a.z) ** 2)


def _path_metrics(points):
    groups = defaultdict(list)
    for p in points:
        groups[(p.layer_id, p.polygon_id)].append(p)

    metrics = {}
    for key, pts in groups.items():
        pts = sorted(pts, key=lambda p: p.point_id)
        cumulative = [0.0]
        seg = [0.0]
        for a, b in zip(pts, pts[1:]):
            length = _distance(a, b)
            seg.append(length)
            cumulative.append(cumulative[-1] + length)
        total = cumulative[-1]
        for p, s, c in zip(pts, seg, cumulative):
            metrics[(p.layer_id, p.polygon_id, p.point_id)] = (s, c, total)
    return metrics


def export_csv(points, cfg: dict):
    path = resolve_path(cfg, cfg["export"]["csv_path"])
    path.parent.mkdir(parents=True, exist_ok=True)
    metrics = _path_metrics(points)

    with path.open("w", newline="", encoding="utf-8") as f:
        writer = csv.DictWriter(f, fieldnames=FIELDS)
        writer.writeheader()
        for p in points:
            seg, cumulative, total = metrics[(p.layer_id, p.polygon_id, p.point_id)]
            writer.writerow(
                {
                    "layer_id": p.layer_id,
                    "polygon_id": p.polygon_id,
                    "offset_index": p.offset_index,
                    "ring_type": p.ring_type,
                    "point_id": p.point_id,
                    "x": f"{p.x:.6f}",
                    "y": f"{p.y:.6f}",
                    "z": f"{p.z:.6f}",
                    "status": p.status,
                    "segment_length": f"{seg:.6f}",
                    "cumulative_length": f"{cumulative:.6f}",
                    "path_length": f"{total:.6f}",
                }
            )
    return path
