from __future__ import annotations

import math
from collections import defaultdict
from dataclasses import dataclass

from shapely.geometry import GeometryCollection, MultiPolygon, Polygon
from shapely.geometry.polygon import orient

from .curve import fit_circle, reconstruct_closed_ring, resample_open_path
from .geometry import distance_xy, transform_xyz
from .thinwall import approximate_centerline


@dataclass
class ToolpathPoint:
    layer_id: int
    polygon_id: int
    offset_index: int
    ring_type: str
    point_id: int
    x: float
    y: float
    z: float
    status: str


def _as_polygon_list(geom) -> list[Polygon]:
    if geom is None or geom.is_empty:
        return []
    if isinstance(geom, Polygon):
        return [geom]
    if isinstance(geom, MultiPolygon):
        return list(geom.geoms)
    if isinstance(geom, GeometryCollection):
        out: list[Polygon] = []
        for part in geom.geoms:
            out.extend(_as_polygon_list(part))
        return out
    return []


def _direction_for_path(index: int, mode: str) -> str:
    if mode == "CW":
        return "CW"
    if mode == "CCW":
        return "CCW"
    return "CW" if index % 2 == 0 else "CCW"


def _normalize_ring(coords, min_segment_length: float) -> list[tuple[float, float]]:
    pts = [(float(x), float(y)) for x, y in coords]
    if len(pts) > 1 and distance_xy(pts[0], pts[-1]) <= 1e-12:
        pts = pts[:-1]
    filtered: list[tuple[float, float]] = []
    for p in pts:
        if not filtered or distance_xy(filtered[-1], p) >= min_segment_length:
            filtered.append(p)
    if len(filtered) > 1 and distance_xy(filtered[-1], filtered[0]) < min_segment_length:
        filtered.pop()
    if len(filtered) < 3:
        return []
    return filtered + [filtered[0]]


def _remove_collinear_vertices(coords: list[tuple[float, float]], tolerance: float):
    if tolerance <= 0 or len(coords) <= 4:
        return coords
    vertices = coords[:-1]
    changed = True
    while changed and len(vertices) > 3:
        changed = False
        keep = []
        n = len(vertices)
        for i, b in enumerate(vertices):
            a = vertices[(i - 1) % n]
            c = vertices[(i + 1) % n]
            acx, acy = c[0] - a[0], c[1] - a[1]
            ac_len = math.hypot(acx, acy)
            if ac_len <= 1e-15:
                keep.append(b)
                continue
            dist = abs(acx * (a[1] - b[1]) - (a[0] - b[0]) * acy) / ac_len
            dot = (b[0] - a[0]) * (b[0] - c[0]) + (b[1] - a[1]) * (b[1] - c[1])
            if dist <= tolerance and dot <= tolerance * tolerance:
                changed = True
            else:
                keep.append(b)
        vertices = keep
    return vertices + [vertices[0]] if len(vertices) >= 3 else []


def _force_ring_direction(coords, direction: str) -> list[tuple[float, float]]:
    poly = Polygon(coords)
    if poly.is_empty:
        return []
    poly = orient(poly, sign=-1.0 if direction == "CW" else 1.0)
    return [(float(x), float(y)) for x, y in poly.exterior.coords]


def _rotate_closed_ring_for_seam(
    coords: list[tuple[float, float]],
    layer_id: int,
    path_index: int,
    cfg: dict,
) -> list[tuple[float, float]]:
    seam = cfg.get("seam", {})
    strategy = str(seam.get("strategy", "fixed")).lower()
    if strategy in {"fixed", "original", "none"} or len(coords) <= 4:
        return coords
    unique = coords[:-1]
    cx = sum(p[0] for p in unique) / len(unique)
    cy = sum(p[1] for p in unique) / len(unique)
    base = float(seam.get("base_angle_deg", 0.0))
    if strategy == "rotate":
        delta = float(seam.get("angle_per_layer_deg", 90.0))
    elif strategy == "golden_angle":
        delta = float(seam.get("angle_per_layer_deg", 137.507764))
    else:
        raise ValueError("seam.strategy must be fixed, rotate, or golden_angle")
    target = base + layer_id * delta + path_index * float(seam.get("angle_per_path_deg", 0.0))
    target = target % 360.0

    def angle_distance(p):
        a = math.degrees(math.atan2(p[1] - cy, p[0] - cx)) % 360.0
        d = abs(a - target)
        return min(d, 360.0 - d)

    idx = min(range(len(unique)), key=lambda i: angle_distance(unique[i]))
    rotated = unique[idx:] + unique[:idx]
    return rotated + [rotated[0]]


def _emit_closed_ring(
    coords,
    layer_id: int,
    offset_index: int,
    ring_type: str,
    z: float,
    direction: str,
    path_index: int,
    cfg: dict,
) -> list[ToolpathPoint]:
    min_seg = float(cfg["toolpath"].get("min_segment_length", 0.01))
    collinear = float(cfg["toolpath"].get("collinear_tolerance", 1e-6))
    coords = _normalize_ring(coords, min_seg)
    if not coords:
        return []
    coords = _remove_collinear_vertices(coords, collinear)
    coords = _force_ring_direction(coords, direction)
    coords, meta = reconstruct_closed_ring(coords, cfg)
    if len(coords) < 4:
        return []
    coords = _rotate_closed_ring_for_seam(coords, layer_id, path_index, cfg)

    metrics = cfg.setdefault("_runtime_metrics", {})
    metrics["curve_modes"] = metrics.get("curve_modes", {})
    mode = meta.get("mode", "unknown")
    metrics["curve_modes"][mode] = metrics["curve_modes"].get(mode, 0) + 1

    out = []
    for i, (x, y) in enumerate(coords):
        tx, ty, tz = transform_xyz(x, y, z, cfg)
        status = "ARC_START" if i == 0 else ("ARC_STOP" if i == len(coords) - 1 else "IDLE")
        out.append(
            ToolpathPoint(layer_id, -1, offset_index, ring_type, i, tx, ty, tz, status)
        )
    return out


def _emit_open_path(
    coords,
    layer_id: int,
    offset_index: int,
    ring_type: str,
    z: float,
    cfg: dict,
) -> list[ToolpathPoint]:
    sampled = resample_open_path(coords, cfg)
    if len(sampled) < 2:
        return []
    out = []
    for i, (x, y) in enumerate(sampled):
        tx, ty, tz = transform_xyz(x, y, z, cfg)
        status = "ARC_START" if i == 0 else ("ARC_STOP" if i == len(sampled) - 1 else "IDLE")
        out.append(ToolpathPoint(layer_id, -1, offset_index, ring_type, i, tx, ty, tz, status))
    return out


def _nearest_order(paths: list[list[ToolpathPoint]], start_xy: tuple[float, float]):
    remaining = list(paths)
    ordered = []
    current = start_xy
    while remaining:
        idx = min(
            range(len(remaining)),
            key=lambda i: math.hypot(remaining[i][0].x - current[0], remaining[i][0].y - current[1]),
        )
        path = remaining.pop(idx)
        ordered.append(path)
        current = (path[-1].x, path[-1].y)
    return ordered


def _order_layer_paths(paths: list[list[ToolpathPoint]], cfg: dict):
    planning = cfg.get("path_order", {})
    strategy = str(planning.get("strategy", "offset_then_nearest")).lower()
    if strategy in {"generated", "none"}:
        return paths
    if strategy != "offset_then_nearest":
        raise ValueError("path_order.strategy must be generated or offset_then_nearest")

    start = planning.get("start_position_xy")
    if start is None:
        current = (paths[0][0].x, paths[0][0].y) if paths else (0.0, 0.0)
    else:
        current = (float(start[0]), float(start[1]))

    groups = defaultdict(list)
    for path in paths:
        groups[path[0].offset_index].append(path)
    ordered = []
    for offset in sorted(groups):
        group = _nearest_order(groups[offset], current)
        ordered.extend(group)
        if group:
            current = (group[-1][-1].x, group[-1][-1].y)
    return ordered



def _maybe_make_concentric_spiral(paths: list[list[ToolpathPoint]], layer_id: int, cfg: dict):
    """Optionally replace concentric circular contour paths by one continuous spiral.

    This is deliberately restricted to a single set of concentric circles with no
    holes/centerlines. It is disabled by default because continuous deposition changes
    WAAM thermal/process behavior and must be validated experimentally.
    """
    sp = cfg.get("continuous_spiral", {})
    if not sp.get("enabled", False) or len(paths) < 2:
        return paths
    if any(p[0].ring_type != "EXTERIOR" for p in paths):
        return paths
    if len({p[0].offset_index for p in paths}) != len(paths):
        return paths

    fits = []
    tol = float(sp.get("circle_fit_tolerance", cfg.get("curve", {}).get("circle_fit_tolerance", 0.05)))
    center_tol = float(sp.get("center_tolerance", 0.10))
    for path in paths:
        fit = fit_circle([(p.x, p.y) for p in path[:-1]])
        if fit is None or fit.max_residual > tol:
            return paths
        fits.append((fit, path))
    cx = sum(f.cx for f, _ in fits) / len(fits)
    cy = sum(f.cy for f, _ in fits) / len(fits)
    if any(math.hypot(f.cx - cx, f.cy - cy) > center_tol for f, _ in fits):
        return paths

    fits.sort(key=lambda item: item[0].radius, reverse=True)
    radii = [item[0].radius for item in fits]
    if any(radii[i] <= radii[i + 1] for i in range(len(radii) - 1)):
        return paths

    outer_path = fits[0][1]
    z = outer_path[0].z
    start_angle = math.atan2(outer_path[0].y - cy, outer_path[0].x - cx)
    # Determine orientation from the original outer path.
    area2 = 0.0
    op = [(p.x, p.y) for p in outer_path[:-1]]
    for a, b in zip(op, op[1:] + op[:1]):
        area2 += a[0] * b[1] - b[0] * a[1]
    sign = 1.0 if area2 >= 0 else -1.0

    max_spacing = float(cfg.get("curve", {}).get("max_spacing", 0.5))
    total_turns = len(radii)
    theta_end = 2.0 * math.pi * total_turns
    transition_turns = max(1, len(radii) - 1)
    dr_dtheta = (radii[-1] - radii[0]) / (2.0 * math.pi * transition_turns)

    def radius_at(theta_abs: float) -> float:
        # First full turn follows the outer contour. Remaining turns transition inward.
        if theta_abs <= 2.0 * math.pi:
            return radii[0]
        frac = min(1.0, (theta_abs - 2.0 * math.pi) / (2.0 * math.pi * transition_turns))
        return radii[0] + frac * (radii[-1] - radii[0])

    coords = []
    theta_abs = 0.0
    while theta_abs < theta_end - 1e-12:
        r = radius_at(theta_abs)
        a = start_angle + sign * theta_abs
        coords.append((cx + r * math.cos(a), cy + r * math.sin(a)))
        local_dr = 0.0 if theta_abs <= 2.0 * math.pi else dr_dtheta
        speed_per_rad = max(1e-9, math.hypot(r, local_dr))
        theta_abs += min(0.25, max_spacing / speed_per_rad)
        if len(coords) > int(cfg["toolpath"].get("max_points_per_path", 200000)):
            raise RuntimeError("Continuous spiral exceeded max_points_per_path")
    r = radii[-1]
    a = start_angle + sign * theta_end
    coords.append((cx + r * math.cos(a), cy + r * math.sin(a)))
    # Re-sample the generated spiral by arclength to avoid a tiny final remainder segment.
    coords = resample_open_path(coords, cfg)

    spiral = []
    for i, (x, y) in enumerate(coords):
        status = "ARC_START" if i == 0 else ("ARC_STOP" if i == len(coords) - 1 else "IDLE")
        spiral.append(
            ToolpathPoint(
                layer_id=layer_id,
                polygon_id=-1,
                offset_index=0,
                ring_type="CONTINUOUS_SPIRAL",
                point_id=i,
                x=float(x),
                y=float(y),
                z=float(z),
                status=status,
            )
        )
    cfg.setdefault("_runtime_metrics", {})["spiralized_layers"] = (
        cfg.setdefault("_runtime_metrics", {}).get("spiralized_layers", 0) + 1
    )
    return [spiral]


def build_toolpath(layers, cfg: dict) -> list[ToolpathPoint]:
    bead_width = float(cfg["toolpath"]["bead_width_W"])
    offset_distance = float(cfg["toolpath"]["offset_factor"]) * bead_width
    min_area = float(cfg["toolpath"].get("min_polygon_area", 0.2))
    simplify_tolerance = float(cfg["toolpath"].get("simplify_tolerance", 0.0))
    mode = cfg["toolpath"]["contour_direction"]
    quad_segs = int(cfg["toolpath"].get("buffer_quad_segs", 8))
    max_iterations = int(cfg["toolpath"].get("max_offset_iterations", 10000))
    thin = cfg.get("thin_wall", {})

    all_points: list[ToolpathPoint] = []
    global_polygon_id = 0
    global_path_index = 0

    for layer in layers:
        current = [p for p in layer.polygons if p.area >= min_area]
        offset_index = 0
        layer_paths: list[list[ToolpathPoint]] = []

        while current:
            if offset_index >= max_iterations:
                raise RuntimeError(
                    f"Exceeded max_offset_iterations={max_iterations} at layer {layer.layer_id}"
                )
            next_generation: list[Polygon] = []
            for poly in current:
                if simplify_tolerance > 0:
                    poly = poly.simplify(simplify_tolerance, preserve_topology=True)
                if poly.is_empty or poly.area < min_area:
                    continue

                # Optional experimental centerline for simple elongated features that
                # cannot accommodate a full bead-radius inward offset.
                use_thin = False
                if thin.get("enabled", False) and offset_index == 0:
                    half_bead = float(thin.get("width_threshold_factor", 0.5)) * bead_width
                    if poly.buffer(-half_bead).is_empty:
                        centerline = approximate_centerline(poly, cfg)
                        if centerline:
                            path = _emit_open_path(
                                centerline,
                                layer.layer_id,
                                offset_index,
                                "THIN_WALL_CENTERLINE",
                                layer.z,
                                cfg,
                            )
                            if path:
                                layer_paths.append(path)
                                global_path_index += 1
                                use_thin = True
                if use_thin:
                    continue

                direction = _direction_for_path(global_path_index, mode)
                path = _emit_closed_ring(
                    poly.exterior.coords,
                    layer.layer_id,
                    offset_index,
                    "EXTERIOR",
                    layer.z,
                    direction,
                    global_path_index,
                    cfg,
                )
                if path:
                    layer_paths.append(path)
                    global_path_index += 1

                for interior in poly.interiors:
                    direction = _direction_for_path(global_path_index, mode)
                    path = _emit_closed_ring(
                        interior.coords,
                        layer.layer_id,
                        offset_index,
                        "HOLE",
                        layer.z,
                        direction,
                        global_path_index,
                        cfg,
                    )
                    if path:
                        layer_paths.append(path)
                        global_path_index += 1

                shrunken = poly.buffer(
                    -offset_distance,
                    quad_segs=quad_segs,
                    join_style="round",
                )
                next_generation.extend(
                    p for p in _as_polygon_list(shrunken) if p.area >= min_area
                )
            current = next_generation
            offset_index += 1

        layer_paths = _maybe_make_concentric_spiral(layer_paths, layer.layer_id, cfg)
        layer_paths = _order_layer_paths(layer_paths, cfg)
        for path in layer_paths:
            for p in path:
                p.polygon_id = global_polygon_id
            all_points.extend(path)
            global_polygon_id += 1

    return all_points
