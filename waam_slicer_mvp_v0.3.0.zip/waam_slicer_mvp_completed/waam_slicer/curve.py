from __future__ import annotations

import math
from dataclasses import dataclass

import numpy as np

from .geometry import distance_xy


@dataclass(frozen=True)
class CircleFit:
    cx: float
    cy: float
    radius: float
    max_residual: float
    rms_residual: float


def _unique_vertices(coords) -> list[tuple[float, float]]:
    pts = [(float(x), float(y)) for x, y in coords]
    if len(pts) > 1 and distance_xy(pts[0], pts[-1]) <= 1e-12:
        pts = pts[:-1]
    return pts


def fit_circle(points) -> CircleFit | None:
    """Least-squares algebraic circle fit.

    Returns None for insufficient/near-collinear data.  Residuals are radial
    distances to the fitted circle, which makes the tolerance interpretable in mm.
    """
    pts = np.asarray(points, dtype=float)
    if len(pts) < 3:
        return None
    x = pts[:, 0]
    y = pts[:, 1]
    a = np.column_stack((2.0 * x, 2.0 * y, np.ones(len(pts))))
    b = x * x + y * y
    try:
        solution, _, rank, _ = np.linalg.lstsq(a, b, rcond=None)
    except np.linalg.LinAlgError:
        return None
    if rank < 3:
        return None
    cx, cy, c = map(float, solution)
    r2 = c + cx * cx + cy * cy
    if not math.isfinite(r2) or r2 <= 1e-16:
        return None
    radius = math.sqrt(r2)
    radial = np.hypot(x - cx, y - cy)
    residual = np.abs(radial - radius)
    return CircleFit(
        cx=cx,
        cy=cy,
        radius=radius,
        max_residual=float(np.max(residual)),
        rms_residual=float(math.sqrt(float(np.mean(residual * residual)))),
    )


def _turn_angle_deg(a, b, c) -> float:
    v1 = (b[0] - a[0], b[1] - a[1])
    v2 = (c[0] - b[0], c[1] - b[1])
    n1 = math.hypot(*v1)
    n2 = math.hypot(*v2)
    if n1 <= 1e-15 or n2 <= 1e-15:
        return 0.0
    cosv = max(-1.0, min(1.0, (v1[0] * v2[0] + v1[1] * v2[1]) / (n1 * n2)))
    return math.degrees(math.acos(cosv))


def _corner_indices(vertices: list[tuple[float, float]], threshold_deg: float) -> list[int]:
    if threshold_deg <= 0 or len(vertices) < 3:
        return []
    out = []
    n = len(vertices)
    for i in range(n):
        if _turn_angle_deg(vertices[(i - 1) % n], vertices[i], vertices[(i + 1) % n]) >= threshold_deg:
            out.append(i)
    return out


def _polyline_sample(points, max_spacing: float) -> list[tuple[float, float]]:
    """Uniform arclength sample of an open polyline, preserving both endpoints."""
    if len(points) <= 1 or max_spacing <= 0:
        return list(points)
    seg = [distance_xy(a, b) for a, b in zip(points, points[1:])]
    total = sum(seg)
    if total <= 1e-15:
        return [points[0]]
    n = max(1, int(math.ceil(total / max_spacing)))
    targets = [total * i / n for i in range(n + 1)]
    cumulative = [0.0]
    for s in seg:
        cumulative.append(cumulative[-1] + s)
    out: list[tuple[float, float]] = []
    j = 0
    for t in targets:
        while j < len(seg) - 1 and cumulative[j + 1] < t - 1e-12:
            j += 1
        a, b = points[j], points[j + 1]
        local = 0.0 if seg[j] <= 1e-15 else (t - cumulative[j]) / seg[j]
        local = max(0.0, min(1.0, local))
        out.append((a[0] + local * (b[0] - a[0]), a[1] + local * (b[1] - a[1])))
    out[0] = points[0]
    out[-1] = points[-1]
    return out


def _circle_step_angle(radius: float, max_spacing: float, chord_tolerance: float) -> float:
    candidates = [2.0 * math.pi]
    if max_spacing > 0:
        candidates.append(max_spacing / max(radius, 1e-15))
    if chord_tolerance > 0 and chord_tolerance < 2.0 * radius:
        value = 1.0 - chord_tolerance / radius
        value = max(-1.0, min(1.0, value))
        candidates.append(2.0 * math.acos(value))
    return max(1e-6, min(candidates))


def _unwrap_angles(points, cx: float, cy: float) -> np.ndarray:
    angles = np.asarray([math.atan2(y - cy, x - cx) for x, y in points], dtype=float)
    return np.unwrap(angles)


def _sample_circle_chain(
    points: list[tuple[float, float]],
    fit: CircleFit,
    max_spacing: float,
    chord_tolerance: float,
    closed: bool,
    max_points: int,
) -> list[tuple[float, float]] | None:
    if closed:
        # Direction follows the signed area of the original ring.
        area2 = 0.0
        for a, b in zip(points, points[1:] + points[:1]):
            area2 += a[0] * b[1] - b[0] * a[1]
        sign = 1.0 if area2 >= 0 else -1.0
        start = math.atan2(points[0][1] - fit.cy, points[0][0] - fit.cx)
        sweep = sign * 2.0 * math.pi
    else:
        angles = _unwrap_angles(points, fit.cx, fit.cy)
        diffs = np.diff(angles)
        if len(diffs) == 0:
            return None
        # Reject a fit that would reverse direction repeatedly.
        nonzero = diffs[np.abs(diffs) > 1e-7]
        if len(nonzero) and min(np.mean(nonzero > 0), np.mean(nonzero < 0)) > 0.2:
            return None
        start = float(angles[0])
        sweep = float(angles[-1] - angles[0])
        if abs(sweep) <= 1e-6 or abs(sweep) > 2.0 * math.pi + 0.2:
            return None

    step = _circle_step_angle(fit.radius, max_spacing, chord_tolerance)
    n = max(1, int(math.ceil(abs(sweep) / step)))
    if n + 1 > max_points:
        raise RuntimeError(
            f"Curve reconstruction requires {n + 1} points, exceeding max_points_per_path={max_points}"
        )
    out = []
    for i in range(n + 1):
        t = i / n
        a = start + sweep * t
        out.append((fit.cx + fit.radius * math.cos(a), fit.cy + fit.radius * math.sin(a)))
    if closed:
        out[-1] = out[0]
    else:
        # Preserve exact endpoints to avoid tiny discontinuities to neighboring chains.
        out[0] = points[0]
        out[-1] = points[-1]
    return out


def _split_at_corners(vertices: list[tuple[float, float]], corner_indices: list[int]):
    """Return open chains from corner to corner, including both corner endpoints."""
    if not corner_indices:
        return [vertices + [vertices[0]]]
    corners = sorted(set(corner_indices))
    n = len(vertices)
    chains = []
    for pos, start_idx in enumerate(corners):
        end_idx = corners[(pos + 1) % len(corners)]
        chain = [vertices[start_idx]]
        i = (start_idx + 1) % n
        while True:
            chain.append(vertices[i])
            if i == end_idx:
                break
            i = (i + 1) % n
        chains.append(chain)
    return chains


def _drop_too_close(points: list[tuple[float, float]], min_spacing: float, closed: bool):
    if min_spacing <= 0 or len(points) <= 2:
        return points
    out = [points[0]]
    terminal = points[-1]
    interior = points[1:-1] if closed or points[-1] != points[0] else points[1:-1]
    for p in interior:
        if distance_xy(out[-1], p) >= min_spacing:
            out.append(p)
    if closed:
        if distance_xy(out[-1], out[0]) < min_spacing and len(out) > 2:
            out.pop()
        out.append(out[0])
    else:
        if distance_xy(out[-1], terminal) < min_spacing and len(out) > 1:
            out[-1] = terminal
        else:
            out.append(terminal)
    return out


def reconstruct_closed_ring(coords, cfg: dict) -> tuple[list[tuple[float, float]], dict]:
    """Reconstruct smooth circular portions and resample a closed ring.

    The routine never assumes the pre-STL CAD curve is known.  It only replaces a
    polyline by a circular representation when the observed vertices fit that circle
    within the configured radial tolerance.  Otherwise it falls back to the original
    polyline, sampled by arclength while preserving detected sharp corners.
    """
    curve_cfg = cfg.get("curve", {})
    enabled = bool(curve_cfg.get("enabled", True))
    vertices = _unique_vertices(coords)
    if len(vertices) < 3:
        return [], {"mode": "invalid"}

    max_spacing = float(curve_cfg.get("max_spacing", cfg.get("toolpath", {}).get("waypoint_spacing", 0.5)))
    min_spacing = float(curve_cfg.get("min_spacing", 0.0))
    chord_tolerance = float(curve_cfg.get("chord_tolerance", 0.05))
    fit_tolerance = float(curve_cfg.get("circle_fit_tolerance", 0.05))
    min_circle_points = int(curve_cfg.get("min_circle_points", 6))
    corner_angle = float(curve_cfg.get("corner_angle_deg", 20.0))
    max_points = int(cfg.get("toolpath", {}).get("max_points_per_path", 200000))

    if not enabled:
        closed = vertices + [vertices[0]]
        sampled = _polyline_sample(closed, max_spacing)
        return _drop_too_close(sampled, min_spacing, True), {"mode": "polyline"}

    corners = _corner_indices(vertices, corner_angle)
    # Smooth closed contour: try a global circle first. This reconstructs cylinders
    # and circular holes from tessellated STL cross-sections.
    if not corners and len(vertices) >= min_circle_points:
        fit = fit_circle(vertices)
        if fit and fit.max_residual <= fit_tolerance:
            sampled = _sample_circle_chain(
                vertices, fit, max_spacing, chord_tolerance, True, max_points
            )
            sampled = _drop_too_close(sampled or [], min_spacing, True)
            return sampled, {
                "mode": "circle",
                "radius": fit.radius,
                "max_residual": fit.max_residual,
            }

    chains = _split_at_corners(vertices, corners)
    rebuilt: list[tuple[float, float]] = []
    arc_count = 0
    for chain in chains:
        sampled = None
        if len(chain) >= min_circle_points:
            fit = fit_circle(chain)
            if fit and fit.max_residual <= fit_tolerance:
                sampled = _sample_circle_chain(
                    chain, fit, max_spacing, chord_tolerance, False, max_points
                )
                if sampled:
                    arc_count += 1
        if not sampled:
            sampled = _polyline_sample(chain, max_spacing)
        if rebuilt and sampled and distance_xy(rebuilt[-1], sampled[0]) <= 1e-9:
            rebuilt.extend(sampled[1:])
        else:
            rebuilt.extend(sampled)

    if not rebuilt:
        return [], {"mode": "invalid"}
    if distance_xy(rebuilt[0], rebuilt[-1]) > 1e-9:
        rebuilt.append(rebuilt[0])
    else:
        rebuilt[-1] = rebuilt[0]
    rebuilt = _drop_too_close(rebuilt, min_spacing, True)
    if len(rebuilt) > max_points:
        raise RuntimeError(
            f"Reconstructed path has {len(rebuilt)} points, exceeding max_points_per_path={max_points}"
        )
    return rebuilt, {"mode": "hybrid" if arc_count else "polyline", "arc_count": arc_count}


def resample_open_path(coords, cfg: dict) -> list[tuple[float, float]]:
    pts = [(float(x), float(y)) for x, y in coords]
    curve_cfg = cfg.get("curve", {})
    max_spacing = float(curve_cfg.get("max_spacing", cfg.get("toolpath", {}).get("waypoint_spacing", 0.5)))
    min_spacing = float(curve_cfg.get("min_spacing", 0.0))
    sampled = _polyline_sample(pts, max_spacing)
    return _drop_too_close(sampled, min_spacing, False)
