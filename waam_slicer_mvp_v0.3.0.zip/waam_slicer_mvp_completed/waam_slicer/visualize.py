from __future__ import annotations

from collections import defaultdict

import matplotlib.pyplot as plt

from .config import resolve_path
from .geometry import transform_xy


def save_layer_previews(layers, points, cfg: dict):
    image_dir = resolve_path(cfg, cfg["export"]["image_dir"])
    image_dir.mkdir(parents=True, exist_ok=True)

    by_layer = defaultdict(list)
    for p in points:
        by_layer[p.layer_id].append(p)

    show_waypoints = bool(cfg["export"].get("show_waypoints", True))
    marker_every = max(1, int(cfg["export"].get("waypoint_marker_every", 10)))

    for layer in layers:
        fig, ax = plt.subplots(figsize=(7, 7))

        # Raw slice polygons transformed to the same machine XY frame as toolpath.
        for poly in layer.polygons:
            ext = [transform_xy(x, y, cfg) for x, y in poly.exterior.coords]
            ax.plot([p[0] for p in ext], [p[1] for p in ext], linewidth=1.0)
            for hole in poly.interiors:
                ring = [transform_xy(x, y, cfg) for x, y in hole.coords]
                ax.plot([p[0] for p in ring], [p[1] for p in ring], linewidth=1.0)

        grouped = defaultdict(list)
        for p in by_layer[layer.layer_id]:
            grouped[p.polygon_id].append(p)

        for pts in grouped.values():
            pts.sort(key=lambda p: p.point_id)
            xs = [p.x for p in pts]
            ys = [p.y for p in pts]
            ax.plot(xs, ys, linewidth=0.9)
            if show_waypoints:
                sampled = pts[::marker_every]
                ax.scatter([p.x for p in sampled], [p.y for p in sampled], s=7)

        ax.set_aspect("equal", adjustable="box")
        ax.set_title(f"Layer {layer.layer_id} | Z={layer.z:.3f} mm")
        ax.set_xlabel("X [mm]")
        ax.set_ylabel("Y [mm]")
        ax.grid(True, linewidth=0.3)
        fig.tight_layout()
        fig.savefig(image_dir / f"layer_{layer.layer_id:04d}.png", dpi=160)
        plt.close(fig)

    return image_dir
