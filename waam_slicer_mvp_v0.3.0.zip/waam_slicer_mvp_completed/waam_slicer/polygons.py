from __future__ import annotations

from dataclasses import dataclass

import numpy as np
from shapely import make_valid
from shapely.geometry import GeometryCollection, MultiPolygon, Polygon


@dataclass
class RingRecord:
    polygon: Polygon
    parent: int | None = None
    depth: int = 0


def _closed_xy(loop_xyz, closure_tolerance: float, require_closed: bool) -> np.ndarray:
    xy = np.asarray(loop_xyz, dtype=float)[:, :2]
    if len(xy) < 3:
        return xy
    gap = float(np.linalg.norm(xy[0] - xy[-1]))
    if gap <= max(closure_tolerance, 1e-12):
        if gap > 1e-12:
            xy = np.vstack([xy, xy[0]])
        else:
            xy[-1] = xy[0]
        return xy
    if require_closed:
        raise ValueError(
            f"Open slice contour detected: endpoint gap={gap:.6f} mm exceeds "
            f"section_closure_tolerance={closure_tolerance:.6f} mm"
        )
    return np.empty((0, 2), dtype=float)


def _polygon_parts(geom) -> list[Polygon]:
    if geom is None or geom.is_empty:
        return []
    if isinstance(geom, Polygon):
        return [geom]
    if isinstance(geom, MultiPolygon):
        return [p for p in geom.geoms if not p.is_empty]
    if isinstance(geom, GeometryCollection):
        out: list[Polygon] = []
        for part in geom.geoms:
            out.extend(_polygon_parts(part))
        return out
    return []


def _clean_polygon(poly: Polygon) -> list[Polygon]:
    geom = poly if poly.is_valid else make_valid(poly)
    return _polygon_parts(geom)


def section_loops_to_polygons(
    discrete_loops,
    min_area: float = 0.2,
    closure_tolerance: float = 0.02,
    require_closed: bool = True,
) -> list[Polygon]:
    """Convert Trimesh section loops into nested material polygons.

    Unlike the earlier version, this function never silently closes a large open
    contour.  Only endpoint gaps within ``closure_tolerance`` are snapped closed.
    """
    rings: list[RingRecord] = []

    for loop in discrete_loops:
        xy = _closed_xy(loop, closure_tolerance, require_closed)
        if len(xy) < 4:
            continue
        for poly in _clean_polygon(Polygon(xy)):
            if poly.area >= min_area:
                rings.append(RingRecord(poly))

    if not rings:
        return []

    order = sorted(range(len(rings)), key=lambda i: rings[i].polygon.area, reverse=True)
    for pos, child_idx in enumerate(order):
        child = rings[child_idx].polygon
        probe = child.representative_point()
        parent_idx = None
        parent_area = float("inf")
        for candidate_idx in order[:pos]:
            candidate = rings[candidate_idx].polygon
            if candidate.area < parent_area and candidate.contains(probe):
                parent_idx = candidate_idx
                parent_area = candidate.area
        rings[child_idx].parent = parent_idx

    def depth_of(idx: int) -> int:
        depth = 0
        parent = rings[idx].parent
        visited = set()
        while parent is not None:
            if parent in visited:
                raise RuntimeError("Invalid cyclic ring hierarchy")
            visited.add(parent)
            depth += 1
            parent = rings[parent].parent
        return depth

    for i in range(len(rings)):
        rings[i].depth = depth_of(i)

    output: list[Polygon] = []
    for i, ring in enumerate(rings):
        if ring.depth % 2 != 0:
            continue
        holes = [
            list(child.polygon.exterior.coords)
            for child in rings
            if child.parent == i and child.depth == ring.depth + 1
        ]
        rebuilt = Polygon(list(ring.polygon.exterior.coords), holes=holes)
        for poly in _clean_polygon(rebuilt):
            if poly.area >= min_area:
                output.append(poly)
    return output
