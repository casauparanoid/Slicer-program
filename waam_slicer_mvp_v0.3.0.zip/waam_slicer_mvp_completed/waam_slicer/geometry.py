from __future__ import annotations

import math
from collections.abc import Iterable


def distance_xy(a: tuple[float, float], b: tuple[float, float]) -> float:
    return math.hypot(float(b[0]) - float(a[0]), float(b[1]) - float(a[1]))


def transform_xyz(x: float, y: float, z: float, cfg: dict) -> tuple[float, float, float]:
    cad = cfg["coordinate_system"]["cad_origin"]
    machine = cfg["coordinate_system"]["machine_origin"]
    placement = cfg.get("_placement_offset", [0.0, 0.0, 0.0])
    return (
        float(x) - float(cad[0]) + float(machine[0]) + float(placement[0]),
        float(y) - float(cad[1]) + float(machine[1]) + float(placement[1]),
        float(z) - float(cad[2]) + float(machine[2]) + float(placement[2]),
    )


def transform_xy(x: float, y: float, cfg: dict) -> tuple[float, float]:
    cad = cfg["coordinate_system"]["cad_origin"]
    machine = cfg["coordinate_system"]["machine_origin"]
    placement = cfg.get("_placement_offset", [0.0, 0.0, 0.0])
    return (
        float(x) - float(cad[0]) + float(machine[0]) + float(placement[0]),
        float(y) - float(cad[1]) + float(machine[1]) + float(placement[1]),
    )


def path_length_xyz(points: Iterable) -> float:
    pts = list(points)
    total = 0.0
    for a, b in zip(pts, pts[1:]):
        total += math.sqrt(
            (float(b.x) - float(a.x)) ** 2
            + (float(b.y) - float(a.y)) ** 2
            + (float(b.z) - float(a.z)) ** 2
        )
    return total
