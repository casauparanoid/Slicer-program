from __future__ import annotations

import math

from shapely.geometry import LineString, MultiLineString, Polygon


def _longest_line(geom):
    if isinstance(geom, LineString):
        return geom
    if isinstance(geom, MultiLineString) and geom.geoms:
        return max(geom.geoms, key=lambda g: g.length)
    return None


def approximate_centerline(poly: Polygon, cfg: dict) -> list[tuple[float, float]]:
    """Experimental centerline for simple elongated thin polygons.

    Uses the major axis of the minimum rotated rectangle and clips it to the
    polygon. It is intentionally conservative and should remain disabled until
    validated for the target WAAM process.
    """
    tw = cfg.get("thin_wall", {})
    rect = poly.minimum_rotated_rectangle
    rc = list(rect.exterior.coords)[:-1]
    if len(rc) != 4:
        return []
    edges = []
    for i in range(4):
        a, b = rc[i], rc[(i + 1) % 4]
        edges.append((math.hypot(b[0] - a[0], b[1] - a[1]), a, b))
    edges.sort(key=lambda e: e[0], reverse=True)
    major, a, b = edges[0]
    minor = edges[-1][0]
    if minor <= 1e-12 or major / minor < float(tw.get("min_aspect_ratio", 2.0)):
        return []
    cx, cy = float(poly.centroid.x), float(poly.centroid.y)
    ux, uy = (b[0] - a[0]) / major, (b[1] - a[1]) / major
    span = max(major, minor) * 3.0 + 10.0
    line = LineString([(cx - ux * span, cy - uy * span), (cx + ux * span, cy + uy * span)])
    clipped = _longest_line(poly.intersection(line))
    if clipped is None or clipped.length < float(tw.get("min_centerline_length", 2.0)):
        return []
    return [(float(x), float(y)) for x, y in clipped.coords]
