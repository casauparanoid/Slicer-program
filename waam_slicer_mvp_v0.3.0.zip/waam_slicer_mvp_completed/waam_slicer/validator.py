from __future__ import annotations

import math
from collections import defaultdict
from dataclasses import dataclass, field

from .geometry import path_length_xyz


@dataclass
class ValidationReport:
    layer_count: int
    path_count: int
    point_count: int
    total_deposition_length_mm: float
    min_segment_mm: float
    max_segment_mm: float
    warnings: list[str] = field(default_factory=list)


def group_paths(points):
    groups = defaultdict(list)
    for p in points:
        groups[(p.layer_id, p.polygon_id)].append(p)
    return [sorted(groups[key], key=lambda p: p.point_id) for key in sorted(groups)]


def group_layers(points):
    groups = defaultdict(list)
    for p in points:
        groups[p.layer_id].append(p)
    return {key: groups[key] for key in sorted(groups)}


def _segment_length(a, b) -> float:
    return math.sqrt((b.x - a.x) ** 2 + (b.y - a.y) ** 2 + (b.z - a.z) ** 2)


def _is_open_path(path) -> bool:
    return bool(path and path[0].ring_type in {"THIN_WALL_CENTERLINE", "CONTINUOUS_SPIRAL"})


def validate_toolpath(points, cfg: dict) -> ValidationReport:
    if not points:
        raise ValueError("Toolpath is empty")

    validation = cfg.get("validation", {})
    tol = float(validation.get("coordinate_tolerance", 1e-6))
    require_closed = bool(validation.get("require_closed_paths", True))
    enforce_limits = bool(validation.get("enforce_machine_limits", False))
    max_spacing = float(cfg.get("curve", {}).get("max_spacing", cfg["toolpath"].get("waypoint_spacing", 0.0)))
    warn_below = float(validation.get("warn_segment_below_mm", 0.0))

    paths = group_paths(points)
    layers = {p.layer_id for p in points}
    segment_lengths: list[float] = []
    total_length = 0.0
    warnings: list[str] = []
    short_count = 0

    for path in paths:
        minimum_points = 2 if _is_open_path(path) else 4
        if len(path) < minimum_points:
            raise ValueError(
                f"Path layer={path[0].layer_id} polygon={path[0].polygon_id} has only {len(path)} points"
            )
        if path[0].status != "ARC_START":
            raise ValueError("Every path must begin with ARC_START")
        if path[-1].status != "ARC_STOP":
            raise ValueError("Every path must end with ARC_STOP")
        if any(p.status not in {"ARC_START", "IDLE", "ARC_STOP"} for p in path):
            raise ValueError("Unknown toolpath status detected")

        expected_ids = list(range(len(path)))
        actual_ids = [p.point_id for p in path]
        if actual_ids != expected_ids:
            raise ValueError(f"Non-contiguous point_id in path polygon={path[0].polygon_id}")

        if require_closed and not _is_open_path(path):
            closure = _segment_length(path[-1], path[0])
            if closure > tol:
                raise ValueError(
                    f"Path polygon={path[0].polygon_id} is not closed; gap={closure:.6f} mm"
                )

        for p in path:
            if not all(math.isfinite(v) for v in (p.x, p.y, p.z)):
                raise ValueError("Toolpath contains NaN/Inf coordinates")

        for a, b in zip(path, path[1:]):
            length = _segment_length(a, b)
            if length <= tol:
                raise ValueError(
                    f"Zero/near-zero segment in polygon={path[0].polygon_id}: {length:.9f} mm"
                )
            segment_lengths.append(length)
            if warn_below > 0 and length < warn_below:
                short_count += 1

        total_length += path_length_xyz(path)

        if max_spacing > 0:
            longest = max(_segment_length(a, b) for a, b in zip(path, path[1:]))
            max_allowed = max_spacing + max(tol, max_spacing * 1e-6)
            if longest > max_allowed:
                raise ValueError(
                    f"Waypoint spacing violated in polygon={path[0].polygon_id}: "
                    f"{longest:.6f} mm > {max_spacing:.6f} mm"
                )

    if enforce_limits:
        limits = validation["machine_limits"]
        for p in points:
            for axis, value in (("x", p.x), ("y", p.y), ("z", p.z)):
                lo, hi = map(float, limits[axis])
                if value < lo - tol or value > hi + tol:
                    raise ValueError(
                        f"Machine limit exceeded: {axis.upper()}={value:.4f} mm outside [{lo}, {hi}]"
                    )

    if not segment_lengths:
        raise ValueError("No deposition segments were generated")
    if short_count:
        warnings.append(
            f"{short_count} deposition segments are shorter than {warn_below:.3f} mm. "
            "Review curve.min_spacing / source STL if motion becomes noisy."
        )

    return ValidationReport(
        layer_count=len(layers),
        path_count=len(paths),
        point_count=len(points),
        total_deposition_length_mm=total_length,
        min_segment_mm=min(segment_lengths),
        max_segment_mm=max(segment_lengths),
        warnings=warnings,
    )
