from __future__ import annotations

import math
from dataclasses import dataclass

import trimesh

from .polygons import section_loops_to_polygons


@dataclass
class SliceLayer:
    layer_id: int
    z: float
    polygons: list
    nominal_z: float | None = None
    is_partial_top_layer: bool = False


def _slice_z_values(mesh: trimesh.Trimesh, cfg: dict) -> list[tuple[float, float, bool]]:
    s = cfg["slicing"]
    z_offset = float(s["z_min"])
    h = float(s["layer_height_H"])
    mode = str(s.get("layer_count_mode", "ceil_partial")).lower()
    eps = float(s.get("surface_epsilon", 0.001))
    z0 = float(mesh.bounds[0, 2])
    zmax = float(mesh.bounds[1, 2])
    first = z0 + z_offset
    if first > zmax + 1e-12:
        if mode == "ceil_partial":
            z = max(z0, zmax - eps)
            return [(float(z), float(first), True)]
        return []

    if mode in {"legacy", "floor"}:
        out = []
        k = 0
        while True:
            nominal = first + k * h
            if nominal > zmax + 1e-9:
                break
            z = nominal
            if z >= zmax and eps > 0:
                z = max(z0, zmax - eps)
            out.append((z, nominal, False))
            k += 1
        return out

    if mode != "ceil_partial":
        raise ValueError("slicing.layer_count_mode must be legacy/floor or ceil_partial")

    remaining = max(0.0, zmax - first)
    count = 1 + int(math.ceil(max(0.0, remaining - 1e-12) / h))
    out = []
    for k in range(count):
        nominal = first + k * h
        partial = nominal > zmax + 1e-9
        if partial:
            z = max(z0, zmax - eps)
        elif nominal >= zmax and eps > 0:
            z = max(z0, zmax - eps)
            partial = True
        else:
            z = nominal
        if out and abs(z - out[-1][0]) <= 1e-9:
            continue
        out.append((float(z), float(nominal), bool(partial)))
    return out


def build_slices(mesh: trimesh.Trimesh, cfg: dict) -> list[SliceLayer]:
    min_area = float(cfg["toolpath"].get("min_polygon_area", 0.2))
    mv = cfg.get("mesh_validation", {})
    closure_tol = float(mv.get("section_closure_tolerance", 0.02))
    require_closed = bool(mv.get("require_closed_sections", True))

    layers: list[SliceLayer] = []
    for z, nominal, partial in _slice_z_values(mesh, cfg):
        section = mesh.section(
            plane_origin=[0.0, 0.0, z],
            plane_normal=[0.0, 0.0, 1.0],
        )
        if section is None:
            if partial:
                continue
            continue
        polygons = section_loops_to_polygons(
            section.discrete,
            min_area=min_area,
            closure_tolerance=closure_tol,
            require_closed=require_closed,
        )
        if polygons:
            layers.append(
                SliceLayer(
                    layer_id=len(layers),
                    z=float(z),
                    polygons=polygons,
                    nominal_z=float(nominal),
                    is_partial_top_layer=partial,
                )
            )
    return layers
