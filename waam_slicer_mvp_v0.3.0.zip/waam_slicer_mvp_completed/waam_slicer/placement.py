from __future__ import annotations


def configure_placement(mesh, cfg: dict) -> tuple[float, float, float]:
    """Compute and store an automatic placement offset.

    Placement is deliberately separate from the CAD->machine origin transform so
    the original coordinate convention remains backwards compatible.
    """
    p = cfg.get("placement", {})
    if not p.get("enabled", False) or str(p.get("mode", "manual")).lower() == "manual":
        offset = (0.0, 0.0, 0.0)
        cfg["_placement_offset"] = list(offset)
        return offset

    mode = str(p.get("mode", "center")).lower()
    area = p.get("build_area", {})
    xlo, xhi = map(float, area.get("x", [0.0, 300.0]))
    ylo, yhi = map(float, area.get("y", [0.0, 300.0]))
    margin = float(p.get("margin_xy", 0.0))
    xlo_i, xhi_i = xlo + margin, xhi - margin
    ylo_i, yhi_i = ylo + margin, yhi - margin
    if xlo_i >= xhi_i or ylo_i >= yhi_i:
        raise ValueError("placement.margin_xy leaves no usable build area")

    # Base transformed mesh bounds before placement.
    cad = cfg["coordinate_system"]["cad_origin"]
    machine = cfg["coordinate_system"]["machine_origin"]
    xmin = float(mesh.bounds[0, 0]) - float(cad[0]) + float(machine[0])
    xmax = float(mesh.bounds[1, 0]) - float(cad[0]) + float(machine[0])
    ymin = float(mesh.bounds[0, 1]) - float(cad[1]) + float(machine[1])
    ymax = float(mesh.bounds[1, 1]) - float(cad[1]) + float(machine[1])

    width = xmax - xmin
    depth = ymax - ymin
    if width > (xhi_i - xlo_i) + 1e-9 or depth > (yhi_i - ylo_i) + 1e-9:
        raise ValueError(
            f"Model XY size {width:.3f} x {depth:.3f} mm does not fit usable build area "
            f"{xhi_i-xlo_i:.3f} x {yhi_i-ylo_i:.3f} mm"
        )

    if mode == "center":
        target_cx = 0.5 * (xlo_i + xhi_i)
        target_cy = 0.5 * (ylo_i + yhi_i)
        dx = target_cx - 0.5 * (xmin + xmax)
        dy = target_cy - 0.5 * (ymin + ymax)
    elif mode in {"min_corner", "lower_left"}:
        dx = xlo_i - xmin
        dy = ylo_i - ymin
    else:
        raise ValueError("placement.mode must be manual, center, or min_corner")

    offset = (float(dx), float(dy), 0.0)
    cfg["_placement_offset"] = list(offset)
    return offset
