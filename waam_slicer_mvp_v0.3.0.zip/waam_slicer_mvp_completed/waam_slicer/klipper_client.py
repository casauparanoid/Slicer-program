from __future__ import annotations

import requests


class KlipperClient:
    def __init__(self, base_url: str, timeout: float = 120):
        self.base_url = base_url.rstrip("/")
        self.timeout = float(timeout)
        self.session = requests.Session()

    def check_connection(self) -> dict:
        """Return Moonraker /printer/info JSON. This does not move the machine."""
        response = self.session.get(self.base_url + "/printer/info", timeout=5)
        response.raise_for_status()
        return response.json()

    def get_printer_state(self) -> tuple[str | None, str | None]:
        data = self.check_connection()
        result = data.get("result", {})
        return result.get("state"), result.get("state_message")

    def require_ready(self) -> None:
        state, message = self.get_printer_state()
        if state != "ready":
            raise RuntimeError(
                f"Klipper is not ready (state={state!r}). "
                f"State message: {message or 'no message returned'}"
            )

    def run_gcode(self, script: str):
        """Send G-code or a Klipper macro through Moonraker."""
        response = self.session.post(
            self.base_url + "/printer/gcode/script",
            json={"script": script},
            timeout=self.timeout,
        )
        response.raise_for_status()
        data = response.json()
        if "error" in data:
            raise RuntimeError(f"Klipper error: {data['error']}")
        return data

    def get_last_probe_position(self) -> dict[str, float]:
        """Read probe.last_probe_position and normalize it to {x,y,z}."""
        response = self.session.post(
            self.base_url + "/printer/objects/query",
            json={"objects": {"probe": ["last_probe_position"]}},
            timeout=10,
        )
        response.raise_for_status()
        data = response.json()

        try:
            position = data["result"]["status"]["probe"]["last_probe_position"]
        except KeyError as exc:
            raise RuntimeError(
                "Moonraker did not return probe.last_probe_position"
            ) from exc

        if position is None:
            raise RuntimeError(
                "No probe result is available yet. Run LAYER_TOUCH/PROBE first."
            )

        if isinstance(position, dict):
            x = float(position["x"])
            y = float(position["y"])
            z = float(position["z"])
        else:
            if len(position) < 3:
                raise RuntimeError(f"Unexpected probe position format: {position!r}")
            x, y, z = map(float, position[:3])

        return {"x": x, "y": y, "z": z}
